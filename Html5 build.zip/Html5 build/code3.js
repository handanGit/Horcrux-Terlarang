gdjs.Game_45Code = {};
gdjs.Game_45Code.GDPlayerObjects1= [];
gdjs.Game_45Code.GDPlayerObjects2= [];
gdjs.Game_45Code.GDPlayerObjects3= [];
gdjs.Game_45Code.GDPlayerObjects4= [];
gdjs.Game_45Code.GDPlayerObjects5= [];
gdjs.Game_45Code.GDNewObjectObjects1= [];
gdjs.Game_45Code.GDNewObjectObjects2= [];
gdjs.Game_45Code.GDNewObjectObjects3= [];
gdjs.Game_45Code.GDNewObjectObjects4= [];
gdjs.Game_45Code.GDNewObjectObjects5= [];
gdjs.Game_45Code.GDGroundLObjects1= [];
gdjs.Game_45Code.GDGroundLObjects2= [];
gdjs.Game_45Code.GDGroundLObjects3= [];
gdjs.Game_45Code.GDGroundLObjects4= [];
gdjs.Game_45Code.GDGroundLObjects5= [];
gdjs.Game_45Code.GDGroundRObjects1= [];
gdjs.Game_45Code.GDGroundRObjects2= [];
gdjs.Game_45Code.GDGroundRObjects3= [];
gdjs.Game_45Code.GDGroundRObjects4= [];
gdjs.Game_45Code.GDGroundRObjects5= [];
gdjs.Game_45Code.GDGroundM1Objects1= [];
gdjs.Game_45Code.GDGroundM1Objects2= [];
gdjs.Game_45Code.GDGroundM1Objects3= [];
gdjs.Game_45Code.GDGroundM1Objects4= [];
gdjs.Game_45Code.GDGroundM1Objects5= [];
gdjs.Game_45Code.GDGroundM2Objects1= [];
gdjs.Game_45Code.GDGroundM2Objects2= [];
gdjs.Game_45Code.GDGroundM2Objects3= [];
gdjs.Game_45Code.GDGroundM2Objects4= [];
gdjs.Game_45Code.GDGroundM2Objects5= [];
gdjs.Game_45Code.GDGroundM3Objects1= [];
gdjs.Game_45Code.GDGroundM3Objects2= [];
gdjs.Game_45Code.GDGroundM3Objects3= [];
gdjs.Game_45Code.GDGroundM3Objects4= [];
gdjs.Game_45Code.GDGroundM3Objects5= [];
gdjs.Game_45Code.GDGroundM4Objects1= [];
gdjs.Game_45Code.GDGroundM4Objects2= [];
gdjs.Game_45Code.GDGroundM4Objects3= [];
gdjs.Game_45Code.GDGroundM4Objects4= [];
gdjs.Game_45Code.GDGroundM4Objects5= [];
gdjs.Game_45Code.GDGroundMr1Objects1= [];
gdjs.Game_45Code.GDGroundMr1Objects2= [];
gdjs.Game_45Code.GDGroundMr1Objects3= [];
gdjs.Game_45Code.GDGroundMr1Objects4= [];
gdjs.Game_45Code.GDGroundMr1Objects5= [];
gdjs.Game_45Code.GDGroundMr2Objects1= [];
gdjs.Game_45Code.GDGroundMr2Objects2= [];
gdjs.Game_45Code.GDGroundMr2Objects3= [];
gdjs.Game_45Code.GDGroundMr2Objects4= [];
gdjs.Game_45Code.GDGroundMr2Objects5= [];
gdjs.Game_45Code.GDGroundMr3Objects1= [];
gdjs.Game_45Code.GDGroundMr3Objects2= [];
gdjs.Game_45Code.GDGroundMr3Objects3= [];
gdjs.Game_45Code.GDGroundMr3Objects4= [];
gdjs.Game_45Code.GDGroundMr3Objects5= [];
gdjs.Game_45Code.GDGroundMu1Objects1= [];
gdjs.Game_45Code.GDGroundMu1Objects2= [];
gdjs.Game_45Code.GDGroundMu1Objects3= [];
gdjs.Game_45Code.GDGroundMu1Objects4= [];
gdjs.Game_45Code.GDGroundMu1Objects5= [];
gdjs.Game_45Code.GDGroundMu2Objects1= [];
gdjs.Game_45Code.GDGroundMu2Objects2= [];
gdjs.Game_45Code.GDGroundMu2Objects3= [];
gdjs.Game_45Code.GDGroundMu2Objects4= [];
gdjs.Game_45Code.GDGroundMu2Objects5= [];
gdjs.Game_45Code.GDGroundMu3Objects1= [];
gdjs.Game_45Code.GDGroundMu3Objects2= [];
gdjs.Game_45Code.GDGroundMu3Objects3= [];
gdjs.Game_45Code.GDGroundMu3Objects4= [];
gdjs.Game_45Code.GDGroundMu3Objects5= [];
gdjs.Game_45Code.GDFloatG1Objects1= [];
gdjs.Game_45Code.GDFloatG1Objects2= [];
gdjs.Game_45Code.GDFloatG1Objects3= [];
gdjs.Game_45Code.GDFloatG1Objects4= [];
gdjs.Game_45Code.GDFloatG1Objects5= [];
gdjs.Game_45Code.GDFloatG2Objects1= [];
gdjs.Game_45Code.GDFloatG2Objects2= [];
gdjs.Game_45Code.GDFloatG2Objects3= [];
gdjs.Game_45Code.GDFloatG2Objects4= [];
gdjs.Game_45Code.GDFloatG2Objects5= [];
gdjs.Game_45Code.GDFloatR1Objects1= [];
gdjs.Game_45Code.GDFloatR1Objects2= [];
gdjs.Game_45Code.GDFloatR1Objects3= [];
gdjs.Game_45Code.GDFloatR1Objects4= [];
gdjs.Game_45Code.GDFloatR1Objects5= [];
gdjs.Game_45Code.GDFloatR2Objects1= [];
gdjs.Game_45Code.GDFloatR2Objects2= [];
gdjs.Game_45Code.GDFloatR2Objects3= [];
gdjs.Game_45Code.GDFloatR2Objects4= [];
gdjs.Game_45Code.GDFloatR2Objects5= [];
gdjs.Game_45Code.GDMovFloatR3Objects1= [];
gdjs.Game_45Code.GDMovFloatR3Objects2= [];
gdjs.Game_45Code.GDMovFloatR3Objects3= [];
gdjs.Game_45Code.GDMovFloatR3Objects4= [];
gdjs.Game_45Code.GDMovFloatR3Objects5= [];
gdjs.Game_45Code.GDMovFloatR2Objects1= [];
gdjs.Game_45Code.GDMovFloatR2Objects2= [];
gdjs.Game_45Code.GDMovFloatR2Objects3= [];
gdjs.Game_45Code.GDMovFloatR2Objects4= [];
gdjs.Game_45Code.GDMovFloatR2Objects5= [];
gdjs.Game_45Code.GDBridgeLObjects1= [];
gdjs.Game_45Code.GDBridgeLObjects2= [];
gdjs.Game_45Code.GDBridgeLObjects3= [];
gdjs.Game_45Code.GDBridgeLObjects4= [];
gdjs.Game_45Code.GDBridgeLObjects5= [];
gdjs.Game_45Code.GDBridgeMObjects1= [];
gdjs.Game_45Code.GDBridgeMObjects2= [];
gdjs.Game_45Code.GDBridgeMObjects3= [];
gdjs.Game_45Code.GDBridgeMObjects4= [];
gdjs.Game_45Code.GDBridgeMObjects5= [];
gdjs.Game_45Code.GDBridgeRObjects1= [];
gdjs.Game_45Code.GDBridgeRObjects2= [];
gdjs.Game_45Code.GDBridgeRObjects3= [];
gdjs.Game_45Code.GDBridgeRObjects4= [];
gdjs.Game_45Code.GDBridgeRObjects5= [];
gdjs.Game_45Code.GDCoinUiObjects1= [];
gdjs.Game_45Code.GDCoinUiObjects2= [];
gdjs.Game_45Code.GDCoinUiObjects3= [];
gdjs.Game_45Code.GDCoinUiObjects4= [];
gdjs.Game_45Code.GDCoinUiObjects5= [];
gdjs.Game_45Code.GDCoinObjects1= [];
gdjs.Game_45Code.GDCoinObjects2= [];
gdjs.Game_45Code.GDCoinObjects3= [];
gdjs.Game_45Code.GDCoinObjects4= [];
gdjs.Game_45Code.GDCoinObjects5= [];
gdjs.Game_45Code.GDScoreDiamondObjects1= [];
gdjs.Game_45Code.GDScoreDiamondObjects2= [];
gdjs.Game_45Code.GDScoreDiamondObjects3= [];
gdjs.Game_45Code.GDScoreDiamondObjects4= [];
gdjs.Game_45Code.GDScoreDiamondObjects5= [];
gdjs.Game_45Code.GDScoreObjects1= [];
gdjs.Game_45Code.GDScoreObjects2= [];
gdjs.Game_45Code.GDScoreObjects3= [];
gdjs.Game_45Code.GDScoreObjects4= [];
gdjs.Game_45Code.GDScoreObjects5= [];
gdjs.Game_45Code.GDOpstaclePatchObjects1= [];
gdjs.Game_45Code.GDOpstaclePatchObjects2= [];
gdjs.Game_45Code.GDOpstaclePatchObjects3= [];
gdjs.Game_45Code.GDOpstaclePatchObjects4= [];
gdjs.Game_45Code.GDOpstaclePatchObjects5= [];
gdjs.Game_45Code.GDPortalObjects1= [];
gdjs.Game_45Code.GDPortalObjects2= [];
gdjs.Game_45Code.GDPortalObjects3= [];
gdjs.Game_45Code.GDPortalObjects4= [];
gdjs.Game_45Code.GDPortalObjects5= [];
gdjs.Game_45Code.GDPortal2Objects1= [];
gdjs.Game_45Code.GDPortal2Objects2= [];
gdjs.Game_45Code.GDPortal2Objects3= [];
gdjs.Game_45Code.GDPortal2Objects4= [];
gdjs.Game_45Code.GDPortal2Objects5= [];
gdjs.Game_45Code.GDPortalaObjects1= [];
gdjs.Game_45Code.GDPortalaObjects2= [];
gdjs.Game_45Code.GDPortalaObjects3= [];
gdjs.Game_45Code.GDPortalaObjects4= [];
gdjs.Game_45Code.GDPortalaObjects5= [];
gdjs.Game_45Code.GDPortala2Objects1= [];
gdjs.Game_45Code.GDPortala2Objects2= [];
gdjs.Game_45Code.GDPortala2Objects3= [];
gdjs.Game_45Code.GDPortala2Objects4= [];
gdjs.Game_45Code.GDPortala2Objects5= [];
gdjs.Game_45Code.GDPortalcObjects1= [];
gdjs.Game_45Code.GDPortalcObjects2= [];
gdjs.Game_45Code.GDPortalcObjects3= [];
gdjs.Game_45Code.GDPortalcObjects4= [];
gdjs.Game_45Code.GDPortalcObjects5= [];
gdjs.Game_45Code.GDPortalc2Objects1= [];
gdjs.Game_45Code.GDPortalc2Objects2= [];
gdjs.Game_45Code.GDPortalc2Objects3= [];
gdjs.Game_45Code.GDPortalc2Objects4= [];
gdjs.Game_45Code.GDPortalc2Objects5= [];
gdjs.Game_45Code.GDTreeBgObjects1= [];
gdjs.Game_45Code.GDTreeBgObjects2= [];
gdjs.Game_45Code.GDTreeBgObjects3= [];
gdjs.Game_45Code.GDTreeBgObjects4= [];
gdjs.Game_45Code.GDTreeBgObjects5= [];
gdjs.Game_45Code.GDDiamondObjects1= [];
gdjs.Game_45Code.GDDiamondObjects2= [];
gdjs.Game_45Code.GDDiamondObjects3= [];
gdjs.Game_45Code.GDDiamondObjects4= [];
gdjs.Game_45Code.GDDiamondObjects5= [];
gdjs.Game_45Code.GDRockBgObjects1= [];
gdjs.Game_45Code.GDRockBgObjects2= [];
gdjs.Game_45Code.GDRockBgObjects3= [];
gdjs.Game_45Code.GDRockBgObjects4= [];
gdjs.Game_45Code.GDRockBgObjects5= [];
gdjs.Game_45Code.GDFireCkObjects1= [];
gdjs.Game_45Code.GDFireCkObjects2= [];
gdjs.Game_45Code.GDFireCkObjects3= [];
gdjs.Game_45Code.GDFireCkObjects4= [];
gdjs.Game_45Code.GDFireCkObjects5= [];
gdjs.Game_45Code.GDCheckpointObjects1= [];
gdjs.Game_45Code.GDCheckpointObjects2= [];
gdjs.Game_45Code.GDCheckpointObjects3= [];
gdjs.Game_45Code.GDCheckpointObjects4= [];
gdjs.Game_45Code.GDCheckpointObjects5= [];
gdjs.Game_45Code.GDHorcruxStoryObjects1= [];
gdjs.Game_45Code.GDHorcruxStoryObjects2= [];
gdjs.Game_45Code.GDHorcruxStoryObjects3= [];
gdjs.Game_45Code.GDHorcruxStoryObjects4= [];
gdjs.Game_45Code.GDHorcruxStoryObjects5= [];
gdjs.Game_45Code.GDHorcrux1Objects1= [];
gdjs.Game_45Code.GDHorcrux1Objects2= [];
gdjs.Game_45Code.GDHorcrux1Objects3= [];
gdjs.Game_45Code.GDHorcrux1Objects4= [];
gdjs.Game_45Code.GDHorcrux1Objects5= [];
gdjs.Game_45Code.GDDeadZoneObjects1= [];
gdjs.Game_45Code.GDDeadZoneObjects2= [];
gdjs.Game_45Code.GDDeadZoneObjects3= [];
gdjs.Game_45Code.GDDeadZoneObjects4= [];
gdjs.Game_45Code.GDDeadZoneObjects5= [];
gdjs.Game_45Code.GDFloatLObjects1= [];
gdjs.Game_45Code.GDFloatLObjects2= [];
gdjs.Game_45Code.GDFloatLObjects3= [];
gdjs.Game_45Code.GDFloatLObjects4= [];
gdjs.Game_45Code.GDFloatLObjects5= [];
gdjs.Game_45Code.GDFloatMObjects1= [];
gdjs.Game_45Code.GDFloatMObjects2= [];
gdjs.Game_45Code.GDFloatMObjects3= [];
gdjs.Game_45Code.GDFloatMObjects4= [];
gdjs.Game_45Code.GDFloatMObjects5= [];
gdjs.Game_45Code.GDFloatRObjects1= [];
gdjs.Game_45Code.GDFloatRObjects2= [];
gdjs.Game_45Code.GDFloatRObjects3= [];
gdjs.Game_45Code.GDFloatRObjects4= [];
gdjs.Game_45Code.GDFloatRObjects5= [];
gdjs.Game_45Code.GDPlayerHbObjects1= [];
gdjs.Game_45Code.GDPlayerHbObjects2= [];
gdjs.Game_45Code.GDPlayerHbObjects3= [];
gdjs.Game_45Code.GDPlayerHbObjects4= [];
gdjs.Game_45Code.GDPlayerHbObjects5= [];
gdjs.Game_45Code.GDSaveHbObjects1= [];
gdjs.Game_45Code.GDSaveHbObjects2= [];
gdjs.Game_45Code.GDSaveHbObjects3= [];
gdjs.Game_45Code.GDSaveHbObjects4= [];
gdjs.Game_45Code.GDSaveHbObjects5= [];
gdjs.Game_45Code.GDEnmObjects1= [];
gdjs.Game_45Code.GDEnmObjects2= [];
gdjs.Game_45Code.GDEnmObjects3= [];
gdjs.Game_45Code.GDEnmObjects4= [];
gdjs.Game_45Code.GDEnmObjects5= [];
gdjs.Game_45Code.GDNpcEwokObjects1= [];
gdjs.Game_45Code.GDNpcEwokObjects2= [];
gdjs.Game_45Code.GDNpcEwokObjects3= [];
gdjs.Game_45Code.GDNpcEwokObjects4= [];
gdjs.Game_45Code.GDNpcEwokObjects5= [];
gdjs.Game_45Code.GDBackgroundObjects1= [];
gdjs.Game_45Code.GDBackgroundObjects2= [];
gdjs.Game_45Code.GDBackgroundObjects3= [];
gdjs.Game_45Code.GDBackgroundObjects4= [];
gdjs.Game_45Code.GDBackgroundObjects5= [];
gdjs.Game_45Code.GDHealth2Objects1= [];
gdjs.Game_45Code.GDHealth2Objects2= [];
gdjs.Game_45Code.GDHealth2Objects3= [];
gdjs.Game_45Code.GDHealth2Objects4= [];
gdjs.Game_45Code.GDHealth2Objects5= [];
gdjs.Game_45Code.GDHealth3Objects1= [];
gdjs.Game_45Code.GDHealth3Objects2= [];
gdjs.Game_45Code.GDHealth3Objects3= [];
gdjs.Game_45Code.GDHealth3Objects4= [];
gdjs.Game_45Code.GDHealth3Objects5= [];
gdjs.Game_45Code.GDHealthObjects1= [];
gdjs.Game_45Code.GDHealthObjects2= [];
gdjs.Game_45Code.GDHealthObjects3= [];
gdjs.Game_45Code.GDHealthObjects4= [];
gdjs.Game_45Code.GDHealthObjects5= [];
gdjs.Game_45Code.GDUpObjects1= [];
gdjs.Game_45Code.GDUpObjects2= [];
gdjs.Game_45Code.GDUpObjects3= [];
gdjs.Game_45Code.GDUpObjects4= [];
gdjs.Game_45Code.GDUpObjects5= [];
gdjs.Game_45Code.GDDownObjects1= [];
gdjs.Game_45Code.GDDownObjects2= [];
gdjs.Game_45Code.GDDownObjects3= [];
gdjs.Game_45Code.GDDownObjects4= [];
gdjs.Game_45Code.GDDownObjects5= [];
gdjs.Game_45Code.GDLavaObjects1= [];
gdjs.Game_45Code.GDLavaObjects2= [];
gdjs.Game_45Code.GDLavaObjects3= [];
gdjs.Game_45Code.GDLavaObjects4= [];
gdjs.Game_45Code.GDLavaObjects5= [];
gdjs.Game_45Code.GDSpikeObjects1= [];
gdjs.Game_45Code.GDSpikeObjects2= [];
gdjs.Game_45Code.GDSpikeObjects3= [];
gdjs.Game_45Code.GDSpikeObjects4= [];
gdjs.Game_45Code.GDSpikeObjects5= [];
gdjs.Game_45Code.GDBgMidObjects1= [];
gdjs.Game_45Code.GDBgMidObjects2= [];
gdjs.Game_45Code.GDBgMidObjects3= [];
gdjs.Game_45Code.GDBgMidObjects4= [];
gdjs.Game_45Code.GDBgMidObjects5= [];
gdjs.Game_45Code.GDBgUpRObjects1= [];
gdjs.Game_45Code.GDBgUpRObjects2= [];
gdjs.Game_45Code.GDBgUpRObjects3= [];
gdjs.Game_45Code.GDBgUpRObjects4= [];
gdjs.Game_45Code.GDBgUpRObjects5= [];
gdjs.Game_45Code.GDBgLObjects1= [];
gdjs.Game_45Code.GDBgLObjects2= [];
gdjs.Game_45Code.GDBgLObjects3= [];
gdjs.Game_45Code.GDBgLObjects4= [];
gdjs.Game_45Code.GDBgLObjects5= [];
gdjs.Game_45Code.GDBgRObjects1= [];
gdjs.Game_45Code.GDBgRObjects2= [];
gdjs.Game_45Code.GDBgRObjects3= [];
gdjs.Game_45Code.GDBgRObjects4= [];
gdjs.Game_45Code.GDBgRObjects5= [];
gdjs.Game_45Code.GDBgLoLObjects1= [];
gdjs.Game_45Code.GDBgLoLObjects2= [];
gdjs.Game_45Code.GDBgLoLObjects3= [];
gdjs.Game_45Code.GDBgLoLObjects4= [];
gdjs.Game_45Code.GDBgLoLObjects5= [];
gdjs.Game_45Code.GDBgLoRObjects1= [];
gdjs.Game_45Code.GDBgLoRObjects2= [];
gdjs.Game_45Code.GDBgLoRObjects3= [];
gdjs.Game_45Code.GDBgLoRObjects4= [];
gdjs.Game_45Code.GDBgLoRObjects5= [];
gdjs.Game_45Code.GDBgUpLObjects1= [];
gdjs.Game_45Code.GDBgUpLObjects2= [];
gdjs.Game_45Code.GDBgUpLObjects3= [];
gdjs.Game_45Code.GDBgUpLObjects4= [];
gdjs.Game_45Code.GDBgUpLObjects5= [];
gdjs.Game_45Code.GDCelengObjects1= [];
gdjs.Game_45Code.GDCelengObjects2= [];
gdjs.Game_45Code.GDCelengObjects3= [];
gdjs.Game_45Code.GDCelengObjects4= [];
gdjs.Game_45Code.GDCelengObjects5= [];
gdjs.Game_45Code.GDCeleng2Objects1= [];
gdjs.Game_45Code.GDCeleng2Objects2= [];
gdjs.Game_45Code.GDCeleng2Objects3= [];
gdjs.Game_45Code.GDCeleng2Objects4= [];
gdjs.Game_45Code.GDCeleng2Objects5= [];
gdjs.Game_45Code.GDPapanObjects1= [];
gdjs.Game_45Code.GDPapanObjects2= [];
gdjs.Game_45Code.GDPapanObjects3= [];
gdjs.Game_45Code.GDPapanObjects4= [];
gdjs.Game_45Code.GDPapanObjects5= [];
gdjs.Game_45Code.GDBarrelObjects1= [];
gdjs.Game_45Code.GDBarrelObjects2= [];
gdjs.Game_45Code.GDBarrelObjects3= [];
gdjs.Game_45Code.GDBarrelObjects4= [];
gdjs.Game_45Code.GDBarrelObjects5= [];
gdjs.Game_45Code.GDSaw2Objects1= [];
gdjs.Game_45Code.GDSaw2Objects2= [];
gdjs.Game_45Code.GDSaw2Objects3= [];
gdjs.Game_45Code.GDSaw2Objects4= [];
gdjs.Game_45Code.GDSaw2Objects5= [];
gdjs.Game_45Code.GDSawObjects1= [];
gdjs.Game_45Code.GDSawObjects2= [];
gdjs.Game_45Code.GDSawObjects3= [];
gdjs.Game_45Code.GDSawObjects4= [];
gdjs.Game_45Code.GDSawObjects5= [];
gdjs.Game_45Code.GDRightGur2Objects1= [];
gdjs.Game_45Code.GDRightGur2Objects2= [];
gdjs.Game_45Code.GDRightGur2Objects3= [];
gdjs.Game_45Code.GDRightGur2Objects4= [];
gdjs.Game_45Code.GDRightGur2Objects5= [];
gdjs.Game_45Code.GDRightGurObjects1= [];
gdjs.Game_45Code.GDRightGurObjects2= [];
gdjs.Game_45Code.GDRightGurObjects3= [];
gdjs.Game_45Code.GDRightGurObjects4= [];
gdjs.Game_45Code.GDRightGurObjects5= [];
gdjs.Game_45Code.GDRightObjects1= [];
gdjs.Game_45Code.GDRightObjects2= [];
gdjs.Game_45Code.GDRightObjects3= [];
gdjs.Game_45Code.GDRightObjects4= [];
gdjs.Game_45Code.GDRightObjects5= [];
gdjs.Game_45Code.GDLeftGur2Objects1= [];
gdjs.Game_45Code.GDLeftGur2Objects2= [];
gdjs.Game_45Code.GDLeftGur2Objects3= [];
gdjs.Game_45Code.GDLeftGur2Objects4= [];
gdjs.Game_45Code.GDLeftGur2Objects5= [];
gdjs.Game_45Code.GDLeftGurObjects1= [];
gdjs.Game_45Code.GDLeftGurObjects2= [];
gdjs.Game_45Code.GDLeftGurObjects3= [];
gdjs.Game_45Code.GDLeftGurObjects4= [];
gdjs.Game_45Code.GDLeftGurObjects5= [];
gdjs.Game_45Code.GDLeftObjects1= [];
gdjs.Game_45Code.GDLeftObjects2= [];
gdjs.Game_45Code.GDLeftObjects3= [];
gdjs.Game_45Code.GDLeftObjects4= [];
gdjs.Game_45Code.GDLeftObjects5= [];
gdjs.Game_45Code.GDFlame2Objects1= [];
gdjs.Game_45Code.GDFlame2Objects2= [];
gdjs.Game_45Code.GDFlame2Objects3= [];
gdjs.Game_45Code.GDFlame2Objects4= [];
gdjs.Game_45Code.GDFlame2Objects5= [];
gdjs.Game_45Code.GDFlame3Objects1= [];
gdjs.Game_45Code.GDFlame3Objects2= [];
gdjs.Game_45Code.GDFlame3Objects3= [];
gdjs.Game_45Code.GDFlame3Objects4= [];
gdjs.Game_45Code.GDFlame3Objects5= [];
gdjs.Game_45Code.GDFlameObjects1= [];
gdjs.Game_45Code.GDFlameObjects2= [];
gdjs.Game_45Code.GDFlameObjects3= [];
gdjs.Game_45Code.GDFlameObjects4= [];
gdjs.Game_45Code.GDFlameObjects5= [];
gdjs.Game_45Code.GDFlameHb2Objects1= [];
gdjs.Game_45Code.GDFlameHb2Objects2= [];
gdjs.Game_45Code.GDFlameHb2Objects3= [];
gdjs.Game_45Code.GDFlameHb2Objects4= [];
gdjs.Game_45Code.GDFlameHb2Objects5= [];
gdjs.Game_45Code.GDFlameHb3Objects1= [];
gdjs.Game_45Code.GDFlameHb3Objects2= [];
gdjs.Game_45Code.GDFlameHb3Objects3= [];
gdjs.Game_45Code.GDFlameHb3Objects4= [];
gdjs.Game_45Code.GDFlameHb3Objects5= [];
gdjs.Game_45Code.GDFlameHbObjects1= [];
gdjs.Game_45Code.GDFlameHbObjects2= [];
gdjs.Game_45Code.GDFlameHbObjects3= [];
gdjs.Game_45Code.GDFlameHbObjects4= [];
gdjs.Game_45Code.GDFlameHbObjects5= [];
gdjs.Game_45Code.GDGuardian2Objects1= [];
gdjs.Game_45Code.GDGuardian2Objects2= [];
gdjs.Game_45Code.GDGuardian2Objects3= [];
gdjs.Game_45Code.GDGuardian2Objects4= [];
gdjs.Game_45Code.GDGuardian2Objects5= [];
gdjs.Game_45Code.GDGuardianObjects1= [];
gdjs.Game_45Code.GDGuardianObjects2= [];
gdjs.Game_45Code.GDGuardianObjects3= [];
gdjs.Game_45Code.GDGuardianObjects4= [];
gdjs.Game_45Code.GDGuardianObjects5= [];
gdjs.Game_45Code.GDTextBox2Objects1= [];
gdjs.Game_45Code.GDTextBox2Objects2= [];
gdjs.Game_45Code.GDTextBox2Objects3= [];
gdjs.Game_45Code.GDTextBox2Objects4= [];
gdjs.Game_45Code.GDTextBox2Objects5= [];
gdjs.Game_45Code.GDTextBox3Objects1= [];
gdjs.Game_45Code.GDTextBox3Objects2= [];
gdjs.Game_45Code.GDTextBox3Objects3= [];
gdjs.Game_45Code.GDTextBox3Objects4= [];
gdjs.Game_45Code.GDTextBox3Objects5= [];
gdjs.Game_45Code.GDTextBox4Objects1= [];
gdjs.Game_45Code.GDTextBox4Objects2= [];
gdjs.Game_45Code.GDTextBox4Objects3= [];
gdjs.Game_45Code.GDTextBox4Objects4= [];
gdjs.Game_45Code.GDTextBox4Objects5= [];
gdjs.Game_45Code.GDTextBoxObjects1= [];
gdjs.Game_45Code.GDTextBoxObjects2= [];
gdjs.Game_45Code.GDTextBoxObjects3= [];
gdjs.Game_45Code.GDTextBoxObjects4= [];
gdjs.Game_45Code.GDTextBoxObjects5= [];
gdjs.Game_45Code.GDStoryPoint2Objects1= [];
gdjs.Game_45Code.GDStoryPoint2Objects2= [];
gdjs.Game_45Code.GDStoryPoint2Objects3= [];
gdjs.Game_45Code.GDStoryPoint2Objects4= [];
gdjs.Game_45Code.GDStoryPoint2Objects5= [];
gdjs.Game_45Code.GDStoryPointObjects1= [];
gdjs.Game_45Code.GDStoryPointObjects2= [];
gdjs.Game_45Code.GDStoryPointObjects3= [];
gdjs.Game_45Code.GDStoryPointObjects4= [];
gdjs.Game_45Code.GDStoryPointObjects5= [];
gdjs.Game_45Code.GDGuardianSensorL2Objects1= [];
gdjs.Game_45Code.GDGuardianSensorL2Objects2= [];
gdjs.Game_45Code.GDGuardianSensorL2Objects3= [];
gdjs.Game_45Code.GDGuardianSensorL2Objects4= [];
gdjs.Game_45Code.GDGuardianSensorL2Objects5= [];
gdjs.Game_45Code.GDGuardianSensorLObjects1= [];
gdjs.Game_45Code.GDGuardianSensorLObjects2= [];
gdjs.Game_45Code.GDGuardianSensorLObjects3= [];
gdjs.Game_45Code.GDGuardianSensorLObjects4= [];
gdjs.Game_45Code.GDGuardianSensorLObjects5= [];
gdjs.Game_45Code.GDGuardianSensorR2Objects1= [];
gdjs.Game_45Code.GDGuardianSensorR2Objects2= [];
gdjs.Game_45Code.GDGuardianSensorR2Objects3= [];
gdjs.Game_45Code.GDGuardianSensorR2Objects4= [];
gdjs.Game_45Code.GDGuardianSensorR2Objects5= [];
gdjs.Game_45Code.GDGuardianSensorRObjects1= [];
gdjs.Game_45Code.GDGuardianSensorRObjects2= [];
gdjs.Game_45Code.GDGuardianSensorRObjects3= [];
gdjs.Game_45Code.GDGuardianSensorRObjects4= [];
gdjs.Game_45Code.GDGuardianSensorRObjects5= [];
gdjs.Game_45Code.GDStoryE2Objects1= [];
gdjs.Game_45Code.GDStoryE2Objects2= [];
gdjs.Game_45Code.GDStoryE2Objects3= [];
gdjs.Game_45Code.GDStoryE2Objects4= [];
gdjs.Game_45Code.GDStoryE2Objects5= [];
gdjs.Game_45Code.GDStoryE3Objects1= [];
gdjs.Game_45Code.GDStoryE3Objects2= [];
gdjs.Game_45Code.GDStoryE3Objects3= [];
gdjs.Game_45Code.GDStoryE3Objects4= [];
gdjs.Game_45Code.GDStoryE3Objects5= [];
gdjs.Game_45Code.GDStoryE1Objects1= [];
gdjs.Game_45Code.GDStoryE1Objects2= [];
gdjs.Game_45Code.GDStoryE1Objects3= [];
gdjs.Game_45Code.GDStoryE1Objects4= [];
gdjs.Game_45Code.GDStoryE1Objects5= [];
gdjs.Game_45Code.GDStory1Objects1= [];
gdjs.Game_45Code.GDStory1Objects2= [];
gdjs.Game_45Code.GDStory1Objects3= [];
gdjs.Game_45Code.GDStory1Objects4= [];
gdjs.Game_45Code.GDStory1Objects5= [];
gdjs.Game_45Code.GDEwokName2Objects1= [];
gdjs.Game_45Code.GDEwokName2Objects2= [];
gdjs.Game_45Code.GDEwokName2Objects3= [];
gdjs.Game_45Code.GDEwokName2Objects4= [];
gdjs.Game_45Code.GDEwokName2Objects5= [];
gdjs.Game_45Code.GDEwokName3Objects1= [];
gdjs.Game_45Code.GDEwokName3Objects2= [];
gdjs.Game_45Code.GDEwokName3Objects3= [];
gdjs.Game_45Code.GDEwokName3Objects4= [];
gdjs.Game_45Code.GDEwokName3Objects5= [];
gdjs.Game_45Code.GDEwokNameObjects1= [];
gdjs.Game_45Code.GDEwokNameObjects2= [];
gdjs.Game_45Code.GDEwokNameObjects3= [];
gdjs.Game_45Code.GDEwokNameObjects4= [];
gdjs.Game_45Code.GDEwokNameObjects5= [];
gdjs.Game_45Code.GDPlayerNameObjects1= [];
gdjs.Game_45Code.GDPlayerNameObjects2= [];
gdjs.Game_45Code.GDPlayerNameObjects3= [];
gdjs.Game_45Code.GDPlayerNameObjects4= [];
gdjs.Game_45Code.GDPlayerNameObjects5= [];
gdjs.Game_45Code.GDEwokText2Objects1= [];
gdjs.Game_45Code.GDEwokText2Objects2= [];
gdjs.Game_45Code.GDEwokText2Objects3= [];
gdjs.Game_45Code.GDEwokText2Objects4= [];
gdjs.Game_45Code.GDEwokText2Objects5= [];
gdjs.Game_45Code.GDEwokText3Objects1= [];
gdjs.Game_45Code.GDEwokText3Objects2= [];
gdjs.Game_45Code.GDEwokText3Objects3= [];
gdjs.Game_45Code.GDEwokText3Objects4= [];
gdjs.Game_45Code.GDEwokText3Objects5= [];
gdjs.Game_45Code.GDEwokTextObjects1= [];
gdjs.Game_45Code.GDEwokTextObjects2= [];
gdjs.Game_45Code.GDEwokTextObjects3= [];
gdjs.Game_45Code.GDEwokTextObjects4= [];
gdjs.Game_45Code.GDEwokTextObjects5= [];
gdjs.Game_45Code.GDStoryE1hObjects1= [];
gdjs.Game_45Code.GDStoryE1hObjects2= [];
gdjs.Game_45Code.GDStoryE1hObjects3= [];
gdjs.Game_45Code.GDStoryE1hObjects4= [];
gdjs.Game_45Code.GDStoryE1hObjects5= [];
gdjs.Game_45Code.GDDungeonBg32Objects1= [];
gdjs.Game_45Code.GDDungeonBg32Objects2= [];
gdjs.Game_45Code.GDDungeonBg32Objects3= [];
gdjs.Game_45Code.GDDungeonBg32Objects4= [];
gdjs.Game_45Code.GDDungeonBg32Objects5= [];
gdjs.Game_45Code.GDDungeonBg3Objects1= [];
gdjs.Game_45Code.GDDungeonBg3Objects2= [];
gdjs.Game_45Code.GDDungeonBg3Objects3= [];
gdjs.Game_45Code.GDDungeonBg3Objects4= [];
gdjs.Game_45Code.GDDungeonBg3Objects5= [];
gdjs.Game_45Code.GDDungeonBg22Objects1= [];
gdjs.Game_45Code.GDDungeonBg22Objects2= [];
gdjs.Game_45Code.GDDungeonBg22Objects3= [];
gdjs.Game_45Code.GDDungeonBg22Objects4= [];
gdjs.Game_45Code.GDDungeonBg22Objects5= [];
gdjs.Game_45Code.GDDungeonBg2Objects1= [];
gdjs.Game_45Code.GDDungeonBg2Objects2= [];
gdjs.Game_45Code.GDDungeonBg2Objects3= [];
gdjs.Game_45Code.GDDungeonBg2Objects4= [];
gdjs.Game_45Code.GDDungeonBg2Objects5= [];
gdjs.Game_45Code.GDDungeonBgObjects1= [];
gdjs.Game_45Code.GDDungeonBgObjects2= [];
gdjs.Game_45Code.GDDungeonBgObjects3= [];
gdjs.Game_45Code.GDDungeonBgObjects4= [];
gdjs.Game_45Code.GDDungeonBgObjects5= [];
gdjs.Game_45Code.GDinvisibleWallObjects1= [];
gdjs.Game_45Code.GDinvisibleWallObjects2= [];
gdjs.Game_45Code.GDinvisibleWallObjects3= [];
gdjs.Game_45Code.GDinvisibleWallObjects4= [];
gdjs.Game_45Code.GDinvisibleWallObjects5= [];
gdjs.Game_45Code.GDBosSoundObjects1= [];
gdjs.Game_45Code.GDBosSoundObjects2= [];
gdjs.Game_45Code.GDBosSoundObjects3= [];
gdjs.Game_45Code.GDBosSoundObjects4= [];
gdjs.Game_45Code.GDBosSoundObjects5= [];
gdjs.Game_45Code.GDrightObjects1= [];
gdjs.Game_45Code.GDrightObjects2= [];
gdjs.Game_45Code.GDrightObjects3= [];
gdjs.Game_45Code.GDrightObjects4= [];
gdjs.Game_45Code.GDrightObjects5= [];
gdjs.Game_45Code.GDleftObjects1= [];
gdjs.Game_45Code.GDleftObjects2= [];
gdjs.Game_45Code.GDleftObjects3= [];
gdjs.Game_45Code.GDleftObjects4= [];
gdjs.Game_45Code.GDleftObjects5= [];
gdjs.Game_45Code.GDspaceObjects1= [];
gdjs.Game_45Code.GDspaceObjects2= [];
gdjs.Game_45Code.GDspaceObjects3= [];
gdjs.Game_45Code.GDspaceObjects4= [];
gdjs.Game_45Code.GDspaceObjects5= [];
gdjs.Game_45Code.GDctrlObjects1= [];
gdjs.Game_45Code.GDctrlObjects2= [];
gdjs.Game_45Code.GDctrlObjects3= [];
gdjs.Game_45Code.GDctrlObjects4= [];
gdjs.Game_45Code.GDctrlObjects5= [];
gdjs.Game_45Code.GDspaceTxObjects1= [];
gdjs.Game_45Code.GDspaceTxObjects2= [];
gdjs.Game_45Code.GDspaceTxObjects3= [];
gdjs.Game_45Code.GDspaceTxObjects4= [];
gdjs.Game_45Code.GDspaceTxObjects5= [];
gdjs.Game_45Code.GDctrlTxObjects1= [];
gdjs.Game_45Code.GDctrlTxObjects2= [];
gdjs.Game_45Code.GDctrlTxObjects3= [];
gdjs.Game_45Code.GDctrlTxObjects4= [];
gdjs.Game_45Code.GDctrlTxObjects5= [];
gdjs.Game_45Code.GDarrowTx2Objects1= [];
gdjs.Game_45Code.GDarrowTx2Objects2= [];
gdjs.Game_45Code.GDarrowTx2Objects3= [];
gdjs.Game_45Code.GDarrowTx2Objects4= [];
gdjs.Game_45Code.GDarrowTx2Objects5= [];
gdjs.Game_45Code.GDarrowTxObjects1= [];
gdjs.Game_45Code.GDarrowTxObjects2= [];
gdjs.Game_45Code.GDarrowTxObjects3= [];
gdjs.Game_45Code.GDarrowTxObjects4= [];
gdjs.Game_45Code.GDarrowTxObjects5= [];


gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Game_45Code.GDPlayerObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDBosSoundObjects2Objects = Hashtable.newFrom({"BosSound": gdjs.Game_45Code.GDBosSoundObjects2});
gdjs.Game_45Code.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("TextBox"), gdjs.Game_45Code.GDTextBoxObjects2);
gdjs.copyArray(runtimeScene.getObjects("TextBox2"), gdjs.Game_45Code.GDTextBox2Objects2);
{for(var i = 0, len = gdjs.Game_45Code.GDTextBox2Objects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDTextBox2Objects2[i].putAroundObject((gdjs.Game_45Code.GDTextBoxObjects2.length !== 0 ? gdjs.Game_45Code.GDTextBoxObjects2[0] : null), 0, 0);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("TextBox"), gdjs.Game_45Code.GDTextBoxObjects2);
gdjs.copyArray(runtimeScene.getObjects("TextBox3"), gdjs.Game_45Code.GDTextBox3Objects2);
{for(var i = 0, len = gdjs.Game_45Code.GDTextBox3Objects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDTextBox3Objects2[i].putAroundObject((gdjs.Game_45Code.GDTextBoxObjects2.length !== 0 ? gdjs.Game_45Code.GDTextBoxObjects2[0] : null), 0, 0);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("TextBox"), gdjs.Game_45Code.GDTextBoxObjects2);
gdjs.copyArray(runtimeScene.getObjects("TextBox4"), gdjs.Game_45Code.GDTextBox4Objects2);
{for(var i = 0, len = gdjs.Game_45Code.GDTextBox4Objects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDTextBox4Objects2[i].putAroundObject((gdjs.Game_45Code.GDTextBoxObjects2.length !== 0 ? gdjs.Game_45Code.GDTextBoxObjects2[0] : null), 0, 0);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("EwokName"), gdjs.Game_45Code.GDEwokNameObjects2);
gdjs.copyArray(runtimeScene.getObjects("EwokName2"), gdjs.Game_45Code.GDEwokName2Objects2);
{for(var i = 0, len = gdjs.Game_45Code.GDEwokName2Objects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDEwokName2Objects2[i].putAroundObject((gdjs.Game_45Code.GDEwokNameObjects2.length !== 0 ? gdjs.Game_45Code.GDEwokNameObjects2[0] : null), 0, 0);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("EwokName"), gdjs.Game_45Code.GDEwokNameObjects2);
gdjs.copyArray(runtimeScene.getObjects("EwokName3"), gdjs.Game_45Code.GDEwokName3Objects2);
{for(var i = 0, len = gdjs.Game_45Code.GDEwokName3Objects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDEwokName3Objects2[i].putAroundObject((gdjs.Game_45Code.GDEwokNameObjects2.length !== 0 ? gdjs.Game_45Code.GDEwokNameObjects2[0] : null), 0, 0);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14338116);
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "D&D Forest Night audio atmosphere.ogg", 1, true, 200, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BosSound"), gdjs.Game_45Code.GDBosSoundObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDBosSoundObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDBosSoundObjects2 */
{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 1);
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "beastv2(Final).ogg", 1, true, 75, 1);
}{for(var i = 0, len = gdjs.Game_45Code.GDBosSoundObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDBosSoundObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("BosSound"), gdjs.Game_45Code.GDBosSoundObjects1);
gdjs.copyArray(runtimeScene.getObjects("Down"), gdjs.Game_45Code.GDDownObjects1);
gdjs.copyArray(runtimeScene.getObjects("EwokText"), gdjs.Game_45Code.GDEwokTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("EwokText2"), gdjs.Game_45Code.GDEwokText2Objects1);
gdjs.copyArray(runtimeScene.getObjects("EwokText3"), gdjs.Game_45Code.GDEwokText3Objects1);
gdjs.copyArray(runtimeScene.getObjects("FlameHb"), gdjs.Game_45Code.GDFlameHbObjects1);
gdjs.copyArray(runtimeScene.getObjects("FlameHb2"), gdjs.Game_45Code.GDFlameHb2Objects1);
gdjs.copyArray(runtimeScene.getObjects("FlameHb3"), gdjs.Game_45Code.GDFlameHb3Objects1);
gdjs.copyArray(runtimeScene.getObjects("GuardianSensorL"), gdjs.Game_45Code.GDGuardianSensorLObjects1);
gdjs.copyArray(runtimeScene.getObjects("GuardianSensorL2"), gdjs.Game_45Code.GDGuardianSensorL2Objects1);
gdjs.copyArray(runtimeScene.getObjects("GuardianSensorR"), gdjs.Game_45Code.GDGuardianSensorRObjects1);
gdjs.copyArray(runtimeScene.getObjects("GuardianSensorR2"), gdjs.Game_45Code.GDGuardianSensorR2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Left"), gdjs.Game_45Code.GDLeftObjects1);
gdjs.copyArray(runtimeScene.getObjects("LeftGur"), gdjs.Game_45Code.GDLeftGurObjects1);
gdjs.copyArray(runtimeScene.getObjects("LeftGur2"), gdjs.Game_45Code.GDLeftGur2Objects1);
gdjs.copyArray(runtimeScene.getObjects("PlayerHb"), gdjs.Game_45Code.GDPlayerHbObjects1);
gdjs.copyArray(runtimeScene.getObjects("Right"), gdjs.Game_45Code.GDRightObjects1);
gdjs.copyArray(runtimeScene.getObjects("RightGur"), gdjs.Game_45Code.GDRightGurObjects1);
gdjs.copyArray(runtimeScene.getObjects("RightGur2"), gdjs.Game_45Code.GDRightGur2Objects1);
gdjs.copyArray(runtimeScene.getObjects("SaveHb"), gdjs.Game_45Code.GDSaveHbObjects1);
gdjs.copyArray(runtimeScene.getObjects("Up"), gdjs.Game_45Code.GDUpObjects1);
gdjs.copyArray(runtimeScene.getObjects("invisibleWall"), gdjs.Game_45Code.GDinvisibleWallObjects1);
{for(var i = 0, len = gdjs.Game_45Code.GDEwokTextObjects1.length ;i < len;++i) {
    gdjs.Game_45Code.GDEwokTextObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Game_45Code.GDEwokText2Objects1.length ;i < len;++i) {
    gdjs.Game_45Code.GDEwokText2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.Game_45Code.GDEwokText3Objects1.length ;i < len;++i) {
    gdjs.Game_45Code.GDEwokText3Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.Game_45Code.GDPlayerHbObjects1.length ;i < len;++i) {
    gdjs.Game_45Code.GDPlayerHbObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Game_45Code.GDSaveHbObjects1.length ;i < len;++i) {
    gdjs.Game_45Code.GDSaveHbObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Game_45Code.GDFlameHbObjects1.length ;i < len;++i) {
    gdjs.Game_45Code.GDFlameHbObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Game_45Code.GDFlameHb2Objects1.length ;i < len;++i) {
    gdjs.Game_45Code.GDFlameHb2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.Game_45Code.GDFlameHb3Objects1.length ;i < len;++i) {
    gdjs.Game_45Code.GDFlameHb3Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.Game_45Code.GDRightObjects1.length ;i < len;++i) {
    gdjs.Game_45Code.GDRightObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Game_45Code.GDLeftObjects1.length ;i < len;++i) {
    gdjs.Game_45Code.GDLeftObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Game_45Code.GDUpObjects1.length ;i < len;++i) {
    gdjs.Game_45Code.GDUpObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Game_45Code.GDDownObjects1.length ;i < len;++i) {
    gdjs.Game_45Code.GDDownObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Game_45Code.GDRightGurObjects1.length ;i < len;++i) {
    gdjs.Game_45Code.GDRightGurObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Game_45Code.GDRightGur2Objects1.length ;i < len;++i) {
    gdjs.Game_45Code.GDRightGur2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.Game_45Code.GDLeftGurObjects1.length ;i < len;++i) {
    gdjs.Game_45Code.GDLeftGurObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Game_45Code.GDLeftGur2Objects1.length ;i < len;++i) {
    gdjs.Game_45Code.GDLeftGur2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.Game_45Code.GDGuardianSensorRObjects1.length ;i < len;++i) {
    gdjs.Game_45Code.GDGuardianSensorRObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Game_45Code.GDGuardianSensorLObjects1.length ;i < len;++i) {
    gdjs.Game_45Code.GDGuardianSensorLObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Game_45Code.GDGuardianSensorR2Objects1.length ;i < len;++i) {
    gdjs.Game_45Code.GDGuardianSensorR2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.Game_45Code.GDGuardianSensorL2Objects1.length ;i < len;++i) {
    gdjs.Game_45Code.GDGuardianSensorL2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.Game_45Code.GDBosSoundObjects1.length ;i < len;++i) {
    gdjs.Game_45Code.GDBosSoundObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Game_45Code.GDinvisibleWallObjects1.length ;i < len;++i) {
    gdjs.Game_45Code.GDinvisibleWallObjects1[i].hide();
}
}}

}


};gdjs.Game_45Code.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDPlayerObjects3[i].getBehavior("PlatformerObject").isMoving() ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDPlayerObjects3[k] = gdjs.Game_45Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Game_45Code.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "LControl"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDPlayerObjects3.length;i<l;++i) {
    if ( !(gdjs.Game_45Code.GDPlayerObjects3[i].getAnimation() == 6) ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDPlayerObjects3[k] = gdjs.Game_45Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Game_45Code.GDPlayerObjects3.length = k;
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Game_45Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDPlayerObjects3[i].setAnimation(2);
}
}{for(var i = 0, len = gdjs.Game_45Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDPlayerObjects3[i].flipX(false);
}
}{for(var i = 0, len = gdjs.Game_45Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDPlayerObjects3[i].returnVariable(gdjs.Game_45Code.GDPlayerObjects3[i].getVariables().getFromIndex(0)).setNumber(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDPlayerObjects3[i].getBehavior("PlatformerObject").isMoving() ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDPlayerObjects3[k] = gdjs.Game_45Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Game_45Code.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "LControl"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDPlayerObjects3.length;i<l;++i) {
    if ( !(gdjs.Game_45Code.GDPlayerObjects3[i].getAnimation() == 6) ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDPlayerObjects3[k] = gdjs.Game_45Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Game_45Code.GDPlayerObjects3.length = k;
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Game_45Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDPlayerObjects3[i].setAnimation(2);
}
}{for(var i = 0, len = gdjs.Game_45Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDPlayerObjects3[i].flipX(true);
}
}{for(var i = 0, len = gdjs.Game_45Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDPlayerObjects3[i].returnVariable(gdjs.Game_45Code.GDPlayerObjects3[i].getVariables().getFromIndex(0)).setNumber(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDPlayerObjects3.length;i<l;++i) {
    if ( !(gdjs.Game_45Code.GDPlayerObjects3[i].getBehavior("PlatformerObject").isMoving()) ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDPlayerObjects3[k] = gdjs.Game_45Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Game_45Code.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "LControl"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDPlayerObjects3.length;i<l;++i) {
    if ( !(gdjs.Game_45Code.GDPlayerObjects3[i].getAnimation() == 6) ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDPlayerObjects3[k] = gdjs.Game_45Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Game_45Code.GDPlayerObjects3.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Game_45Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDPlayerObjects3[i].setAnimation(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDPlayerObjects3[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDPlayerObjects3[k] = gdjs.Game_45Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Game_45Code.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "LControl"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDPlayerObjects3.length;i<l;++i) {
    if ( !(gdjs.Game_45Code.GDPlayerObjects3[i].getAnimation() == 6) ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDPlayerObjects3[k] = gdjs.Game_45Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Game_45Code.GDPlayerObjects3.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Game_45Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDPlayerObjects3[i].setAnimation(3);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDPlayerObjects3[i].getBehavior("PlatformerObject").isFalling() ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDPlayerObjects3[k] = gdjs.Game_45Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Game_45Code.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "LControl"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDPlayerObjects3.length;i<l;++i) {
    if ( !(gdjs.Game_45Code.GDPlayerObjects3[i].getAnimation() == 6) ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDPlayerObjects3[k] = gdjs.Game_45Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Game_45Code.GDPlayerObjects3.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Game_45Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDPlayerObjects3[i].setAnimation(4);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDPlayerObjects3[i].getBehavior("PlatformerObject").isGrabbingPlatform() ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDPlayerObjects3[k] = gdjs.Game_45Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Game_45Code.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "LControl"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDPlayerObjects3.length;i<l;++i) {
    if ( !(gdjs.Game_45Code.GDPlayerObjects3[i].getAnimation() == 6) ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDPlayerObjects3[k] = gdjs.Game_45Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Game_45Code.GDPlayerObjects3.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Game_45Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDPlayerObjects3[i].setAnimation(5);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDPlayerObjects3[i].getBehavior("PlatformerObject").isGrabbingPlatform() ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDPlayerObjects3[k] = gdjs.Game_45Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Game_45Code.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Game_45Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDPlayerObjects3[i].setAnimation(5);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14354492);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "salamisound-6718888-sfx-jump-2-game-computer.mp3", false, 5, 1);
}}

}


{



}


};gdjs.Game_45Code.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "LControl");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14356916);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects3);
{for(var i = 0, len = gdjs.Game_45Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDPlayerObjects3[i].setAnimation(6);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "zapsplat_warfare_sword_swing_medium_whoosh_blade_ring_003_43817.mp3", false, 25, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDPlayerObjects3[i].getAnimation() == 6 ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDPlayerObjects3[k] = gdjs.Game_45Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Game_45Code.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDPlayerObjects3[i].hasAnimationEndedLegacy() ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDPlayerObjects3[k] = gdjs.Game_45Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Game_45Code.GDPlayerObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Game_45Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDPlayerObjects3[i].setAnimation(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDPlayerObjects3[i].getAnimation() == 6 ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDPlayerObjects3[k] = gdjs.Game_45Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Game_45Code.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDPlayerObjects3[i].getAnimationFrame() == 3 ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDPlayerObjects3[k] = gdjs.Game_45Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Game_45Code.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDPlayerObjects3[i].getVariableNumber(gdjs.Game_45Code.GDPlayerObjects3[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDPlayerObjects3[k] = gdjs.Game_45Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Game_45Code.GDPlayerObjects3.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDPlayerObjects3 */
gdjs.copyArray(runtimeScene.getObjects("PlayerHb"), gdjs.Game_45Code.GDPlayerHbObjects3);
{for(var i = 0, len = gdjs.Game_45Code.GDPlayerHbObjects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDPlayerHbObjects3[i].putAroundObject((gdjs.Game_45Code.GDPlayerObjects3.length !== 0 ? gdjs.Game_45Code.GDPlayerObjects3[0] : null), 100, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDPlayerObjects3[i].getAnimation() == 6 ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDPlayerObjects3[k] = gdjs.Game_45Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Game_45Code.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDPlayerObjects3[i].getAnimationFrame() == 3 ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDPlayerObjects3[k] = gdjs.Game_45Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Game_45Code.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDPlayerObjects3[i].getVariableNumber(gdjs.Game_45Code.GDPlayerObjects3[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDPlayerObjects3[k] = gdjs.Game_45Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Game_45Code.GDPlayerObjects3.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDPlayerObjects3 */
gdjs.copyArray(runtimeScene.getObjects("PlayerHb"), gdjs.Game_45Code.GDPlayerHbObjects3);
{for(var i = 0, len = gdjs.Game_45Code.GDPlayerHbObjects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDPlayerHbObjects3[i].putAroundObject((gdjs.Game_45Code.GDPlayerObjects3.length !== 0 ? gdjs.Game_45Code.GDPlayerObjects3[0] : null), -(100), 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDPlayerObjects2[i].getAnimation() == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDPlayerObjects2[k] = gdjs.Game_45Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Game_45Code.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PlayerHb"), gdjs.Game_45Code.GDPlayerHbObjects2);
gdjs.copyArray(runtimeScene.getObjects("SaveHb"), gdjs.Game_45Code.GDSaveHbObjects2);
{for(var i = 0, len = gdjs.Game_45Code.GDPlayerHbObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDPlayerHbObjects2[i].putAroundObject((gdjs.Game_45Code.GDSaveHbObjects2.length !== 0 ? gdjs.Game_45Code.GDSaveHbObjects2[0] : null), 100, 0);
}
}}

}


};gdjs.Game_45Code.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDPlayerObjects2[i].getVariableNumber(gdjs.Game_45Code.GDPlayerObjects2[i].getVariables().getFromIndex(1)) == 3 ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDPlayerObjects2[k] = gdjs.Game_45Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Game_45Code.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Health"), gdjs.Game_45Code.GDHealthObjects2);
gdjs.copyArray(runtimeScene.getObjects("Health2"), gdjs.Game_45Code.GDHealth2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Health3"), gdjs.Game_45Code.GDHealth3Objects2);
{for(var i = 0, len = gdjs.Game_45Code.GDHealthObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDHealthObjects2[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.Game_45Code.GDHealth2Objects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDHealth2Objects2[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.Game_45Code.GDHealth3Objects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDHealth3Objects2[i].setAnimation(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDPlayerObjects2[i].getVariableNumber(gdjs.Game_45Code.GDPlayerObjects2[i].getVariables().getFromIndex(1)) == 2 ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDPlayerObjects2[k] = gdjs.Game_45Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Game_45Code.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Health"), gdjs.Game_45Code.GDHealthObjects2);
gdjs.copyArray(runtimeScene.getObjects("Health2"), gdjs.Game_45Code.GDHealth2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Health3"), gdjs.Game_45Code.GDHealth3Objects2);
{for(var i = 0, len = gdjs.Game_45Code.GDHealthObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDHealthObjects2[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.Game_45Code.GDHealth2Objects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDHealth2Objects2[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.Game_45Code.GDHealth3Objects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDHealth3Objects2[i].setAnimation(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDPlayerObjects2[i].getVariableNumber(gdjs.Game_45Code.GDPlayerObjects2[i].getVariables().getFromIndex(1)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDPlayerObjects2[k] = gdjs.Game_45Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Game_45Code.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Health"), gdjs.Game_45Code.GDHealthObjects2);
gdjs.copyArray(runtimeScene.getObjects("Health2"), gdjs.Game_45Code.GDHealth2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Health3"), gdjs.Game_45Code.GDHealth3Objects2);
{for(var i = 0, len = gdjs.Game_45Code.GDHealthObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDHealthObjects2[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.Game_45Code.GDHealth2Objects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDHealth2Objects2[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.Game_45Code.GDHealth3Objects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDHealth3Objects2[i].setAnimation(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDPlayerObjects1[i].getVariableNumber(gdjs.Game_45Code.GDPlayerObjects1[i].getVariables().getFromIndex(1)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDPlayerObjects1[k] = gdjs.Game_45Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.Game_45Code.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Health"), gdjs.Game_45Code.GDHealthObjects1);
gdjs.copyArray(runtimeScene.getObjects("Health2"), gdjs.Game_45Code.GDHealth2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Health3"), gdjs.Game_45Code.GDHealth3Objects1);
{for(var i = 0, len = gdjs.Game_45Code.GDHealthObjects1.length ;i < len;++i) {
    gdjs.Game_45Code.GDHealthObjects1[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.Game_45Code.GDHealth2Objects1.length ;i < len;++i) {
    gdjs.Game_45Code.GDHealth2Objects1[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.Game_45Code.GDHealth3Objects1.length ;i < len;++i) {
    gdjs.Game_45Code.GDHealth3Objects1[i].setAnimation(1);
}
}{gdjs.evtTools.variable.variableClearChildren(runtimeScene.getGame().getVariables().getFromIndex(0));
}{gdjs.evtTools.variable.variableClearChildren(runtimeScene.getGame().getVariables().getFromIndex(1));
}{gdjs.evtTools.variable.variableClearChildren(runtimeScene.getGame().getVariables().getFromIndex(2));
}{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 1);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "ScoreBoard-", false);
}}

}


};gdjs.Game_45Code.eventsList4 = function(runtimeScene) {

{


gdjs.Game_45Code.eventsList1(runtimeScene);
}


{


gdjs.Game_45Code.eventsList2(runtimeScene);
}


{


gdjs.Game_45Code.eventsList3(runtimeScene);
}


};gdjs.Game_45Code.eventsList5 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects1);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.Game_45Code.GDPlayerObjects1.length !== 0 ? gdjs.Game_45Code.GDPlayerObjects1[0] : null), true, "", 0);
}}

}


};gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Game_45Code.GDPlayerObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDCoinObjects2Objects = Hashtable.newFrom({"Coin": gdjs.Game_45Code.GDCoinObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Game_45Code.GDPlayerObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDDiamondObjects2Objects = Hashtable.newFrom({"Diamond": gdjs.Game_45Code.GDDiamondObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Game_45Code.GDPlayerObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDHorcrux1Objects2Objects = Hashtable.newFrom({"Horcrux1": gdjs.Game_45Code.GDHorcrux1Objects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Game_45Code.GDPlayerObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDHealthObjects2Objects = Hashtable.newFrom({"Health": gdjs.Game_45Code.GDHealthObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Game_45Code.GDPlayerObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDHealthObjects2Objects = Hashtable.newFrom({"Health": gdjs.Game_45Code.GDHealthObjects2});
gdjs.Game_45Code.eventsList6 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Coin"), gdjs.Game_45Code.GDCoinObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDCoinObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14368852);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDCoinObjects2 */
{gdjs.evtTools.sound.playSound(runtimeScene, "Coin.mp3", false, 25, 1);
}{for(var i = 0, len = gdjs.Game_45Code.GDCoinObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDCoinObjects2[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getGame().getVariables().getFromIndex(0).add(1);
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.Game_45Code.GDScoreObjects2);
{for(var i = 0, len = gdjs.Game_45Code.GDScoreObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDScoreObjects2[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Diamond"), gdjs.Game_45Code.GDDiamondObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDDiamondObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14370660);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDDiamondObjects2 */
{for(var i = 0, len = gdjs.Game_45Code.GDDiamondObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDDiamondObjects2[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getGame().getVariables().getFromIndex(1).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "diamond coin.mp3", false, 25, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Horcrux1"), gdjs.Game_45Code.GDHorcrux1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDHorcrux1Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14372028);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDHorcrux1Objects2 */
{for(var i = 0, len = gdjs.Game_45Code.GDHorcrux1Objects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDHorcrux1Objects2[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getGame().getVariables().getFromIndex(2).setNumber(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "evil-laugh_2.mp3", false, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Health"), gdjs.Game_45Code.GDHealthObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDHealthObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDPlayerObjects2.length;i<l;++i) {
    if ( !(gdjs.Game_45Code.GDPlayerObjects2[i].getVariableNumber(gdjs.Game_45Code.GDPlayerObjects2[i].getVariables().getFromIndex(1)) == 3) ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDPlayerObjects2[k] = gdjs.Game_45Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Game_45Code.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14373860);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDHealthObjects2 */
/* Reuse gdjs.Game_45Code.GDPlayerObjects2 */
{gdjs.evtTools.sound.playSound(runtimeScene, "health.mp3", false, 25, 1);
}{for(var i = 0, len = gdjs.Game_45Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDPlayerObjects2[i].returnVariable(gdjs.Game_45Code.GDPlayerObjects2[i].getVariables().getFromIndex(1)).add(1);
}
}{for(var i = 0, len = gdjs.Game_45Code.GDHealthObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDHealthObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Health"), gdjs.Game_45Code.GDHealthObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDHealthObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDPlayerObjects2[i].getVariableNumber(gdjs.Game_45Code.GDPlayerObjects2[i].getVariables().getFromIndex(1)) == 3 ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDPlayerObjects2[k] = gdjs.Game_45Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Game_45Code.GDPlayerObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDHealthObjects2 */
{for(var i = 0, len = gdjs.Game_45Code.GDHealthObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDHealthObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("ScoreDiamond"), gdjs.Game_45Code.GDScoreDiamondObjects1);
{for(var i = 0, len = gdjs.Game_45Code.GDScoreDiamondObjects1.length ;i < len;++i) {
    gdjs.Game_45Code.GDScoreDiamondObjects1[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1)));
}
}}

}


};gdjs.Game_45Code.eventsList7 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Background"), gdjs.Game_45Code.GDBackgroundObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects1);
{for(var i = 0, len = gdjs.Game_45Code.GDBackgroundObjects1.length ;i < len;++i) {
    gdjs.Game_45Code.GDBackgroundObjects1[i].putAroundObject((gdjs.Game_45Code.GDPlayerObjects1.length !== 0 ? gdjs.Game_45Code.GDPlayerObjects1[0] : null), 0, 0);
}
}}

}


};gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Game_45Code.GDPlayerObjects3});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDGuardianSensorLObjects3Objects = Hashtable.newFrom({"GuardianSensorL": gdjs.Game_45Code.GDGuardianSensorLObjects3});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Game_45Code.GDPlayerObjects3});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDGuardianSensorRObjects3Objects = Hashtable.newFrom({"GuardianSensorR": gdjs.Game_45Code.GDGuardianSensorRObjects3});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDGuardianObjects3Objects = Hashtable.newFrom({"Guardian": gdjs.Game_45Code.GDGuardianObjects3});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Game_45Code.GDPlayerObjects3});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDGuardianObjects3Objects = Hashtable.newFrom({"Guardian": gdjs.Game_45Code.GDGuardianObjects3});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Game_45Code.GDPlayerObjects3});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Game_45Code.GDPlayerObjects3});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDGuardianObjects3Objects = Hashtable.newFrom({"Guardian": gdjs.Game_45Code.GDGuardianObjects3});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDGuardianObjects3Objects = Hashtable.newFrom({"Guardian": gdjs.Game_45Code.GDGuardianObjects3});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerHbObjects3Objects = Hashtable.newFrom({"PlayerHb": gdjs.Game_45Code.GDPlayerHbObjects3});
gdjs.Game_45Code.eventsList8 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.Game_45Code.GDGuardianObjects3, gdjs.Game_45Code.GDGuardianObjects4);

{for(var i = 0, len = gdjs.Game_45Code.GDGuardianObjects4.length ;i < len;++i) {
    gdjs.Game_45Code.GDGuardianObjects4[i].returnVariable(gdjs.Game_45Code.GDGuardianObjects4[i].getVariables().getFromIndex(0)).sub(1);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "portal-gun-limbo.mp3", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.Game_45Code.GDGuardianObjects3 */
{for(var i = 0, len = gdjs.Game_45Code.GDGuardianObjects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDGuardianObjects3[i].returnVariable(gdjs.Game_45Code.GDGuardianObjects3[i].getVariables().getFromIndex(2)).setNumber(1);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "portal-gun-limbo.mp3", false, 100, 1);
}}

}


};gdjs.Game_45Code.eventsList9 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Game_45Code.GDGuardianObjects2, gdjs.Game_45Code.GDGuardianObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDGuardianObjects3.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDGuardianObjects3[i].getVariableString(gdjs.Game_45Code.GDGuardianObjects3[i].getVariables().getFromIndex(1)) == "left" ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDGuardianObjects3[k] = gdjs.Game_45Code.GDGuardianObjects3[i];
        ++k;
    }
}
gdjs.Game_45Code.GDGuardianObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDGuardianObjects3 */
gdjs.copyArray(runtimeScene.getObjects("LeftGur"), gdjs.Game_45Code.GDLeftGurObjects3);
{for(var i = 0, len = gdjs.Game_45Code.GDGuardianObjects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDGuardianObjects3[i].setX((( gdjs.Game_45Code.GDLeftGurObjects3.length === 0 ) ? 0 :gdjs.Game_45Code.GDLeftGurObjects3[0].getPointX("")));
}
}}

}


{

gdjs.copyArray(gdjs.Game_45Code.GDGuardianObjects2, gdjs.Game_45Code.GDGuardianObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDGuardianObjects3.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDGuardianObjects3[i].getVariableString(gdjs.Game_45Code.GDGuardianObjects3[i].getVariables().getFromIndex(1)) == "right" ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDGuardianObjects3[k] = gdjs.Game_45Code.GDGuardianObjects3[i];
        ++k;
    }
}
gdjs.Game_45Code.GDGuardianObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDGuardianObjects3 */
gdjs.copyArray(runtimeScene.getObjects("RightGur"), gdjs.Game_45Code.GDRightGurObjects3);
{for(var i = 0, len = gdjs.Game_45Code.GDGuardianObjects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDGuardianObjects3[i].setX((( gdjs.Game_45Code.GDRightGurObjects3.length === 0 ) ? 0 :gdjs.Game_45Code.GDRightGurObjects3[0].getPointX("")));
}
}}

}


{

gdjs.copyArray(gdjs.Game_45Code.GDGuardianObjects2, gdjs.Game_45Code.GDGuardianObjects3);

gdjs.copyArray(runtimeScene.getObjects("LeftGur"), gdjs.Game_45Code.GDLeftGurObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDGuardianObjects3.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDGuardianObjects3[i].getX() == (( gdjs.Game_45Code.GDLeftGurObjects3.length === 0 ) ? 0 :gdjs.Game_45Code.GDLeftGurObjects3[0].getPointX("")) ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDGuardianObjects3[k] = gdjs.Game_45Code.GDGuardianObjects3[i];
        ++k;
    }
}
gdjs.Game_45Code.GDGuardianObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDGuardianObjects3 */
{for(var i = 0, len = gdjs.Game_45Code.GDGuardianObjects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDGuardianObjects3[i].returnVariable(gdjs.Game_45Code.GDGuardianObjects3[i].getVariables().getFromIndex(1)).setString("right");
}
}{for(var i = 0, len = gdjs.Game_45Code.GDGuardianObjects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDGuardianObjects3[i].returnVariable(gdjs.Game_45Code.GDGuardianObjects3[i].getVariables().getFromIndex(2)).setNumber(0);
}
}}

}


{

gdjs.copyArray(gdjs.Game_45Code.GDGuardianObjects2, gdjs.Game_45Code.GDGuardianObjects3);

gdjs.copyArray(runtimeScene.getObjects("RightGur"), gdjs.Game_45Code.GDRightGurObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDGuardianObjects3.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDGuardianObjects3[i].getX() == (( gdjs.Game_45Code.GDRightGurObjects3.length === 0 ) ? 0 :gdjs.Game_45Code.GDRightGurObjects3[0].getPointX("")) ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDGuardianObjects3[k] = gdjs.Game_45Code.GDGuardianObjects3[i];
        ++k;
    }
}
gdjs.Game_45Code.GDGuardianObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDGuardianObjects3 */
{for(var i = 0, len = gdjs.Game_45Code.GDGuardianObjects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDGuardianObjects3[i].returnVariable(gdjs.Game_45Code.GDGuardianObjects3[i].getVariables().getFromIndex(1)).setString("left");
}
}{for(var i = 0, len = gdjs.Game_45Code.GDGuardianObjects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDGuardianObjects3[i].returnVariable(gdjs.Game_45Code.GDGuardianObjects3[i].getVariables().getFromIndex(2)).setNumber(0);
}
}}

}


{

/* Reuse gdjs.Game_45Code.GDGuardianObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDGuardianObjects2.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDGuardianObjects2[i].getVariableNumber(gdjs.Game_45Code.GDGuardianObjects2[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDGuardianObjects2[k] = gdjs.Game_45Code.GDGuardianObjects2[i];
        ++k;
    }
}
gdjs.Game_45Code.GDGuardianObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDGuardianObjects2 */
gdjs.copyArray(runtimeScene.getObjects("GuardianSensorL"), gdjs.Game_45Code.GDGuardianSensorLObjects2);
gdjs.copyArray(runtimeScene.getObjects("GuardianSensorR"), gdjs.Game_45Code.GDGuardianSensorRObjects2);
{for(var i = 0, len = gdjs.Game_45Code.GDGuardianObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDGuardianObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Game_45Code.GDGuardianSensorLObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDGuardianSensorLObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Game_45Code.GDGuardianSensorRObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDGuardianSensorRObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.Game_45Code.eventsList10 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("GuardianSensorL"), gdjs.Game_45Code.GDGuardianSensorLObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects3Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDGuardianSensorLObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Guardian"), gdjs.Game_45Code.GDGuardianObjects3);
{for(var i = 0, len = gdjs.Game_45Code.GDGuardianObjects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDGuardianObjects3[i].flipX(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GuardianSensorR"), gdjs.Game_45Code.GDGuardianSensorRObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects3Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDGuardianSensorRObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Guardian"), gdjs.Game_45Code.GDGuardianObjects3);
{for(var i = 0, len = gdjs.Game_45Code.GDGuardianObjects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDGuardianObjects3[i].flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Guardian"), gdjs.Game_45Code.GDGuardianObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDGuardianObjects3Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects3Objects, 600, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDGuardianObjects3 */
{for(var i = 0, len = gdjs.Game_45Code.GDGuardianObjects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDGuardianObjects3[i].setAnimation(3);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Guardian"), gdjs.Game_45Code.GDGuardianObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDGuardianObjects3Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects3Objects, 600, true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDGuardianObjects3.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDGuardianObjects3[i].hasAnimationEndedLegacy() ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDGuardianObjects3[k] = gdjs.Game_45Code.GDGuardianObjects3[i];
        ++k;
    }
}
gdjs.Game_45Code.GDGuardianObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDGuardianObjects3 */
{for(var i = 0, len = gdjs.Game_45Code.GDGuardianObjects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDGuardianObjects3[i].setAnimation(0);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Guardian"), gdjs.Game_45Code.GDGuardianObjects3);
gdjs.copyArray(runtimeScene.getObjects("GuardianSensorL"), gdjs.Game_45Code.GDGuardianSensorLObjects3);
gdjs.copyArray(runtimeScene.getObjects("GuardianSensorR"), gdjs.Game_45Code.GDGuardianSensorRObjects3);
{for(var i = 0, len = gdjs.Game_45Code.GDGuardianSensorLObjects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDGuardianSensorLObjects3[i].putAroundObject((gdjs.Game_45Code.GDGuardianObjects3.length !== 0 ? gdjs.Game_45Code.GDGuardianObjects3[0] : null), -(400), 0);
}
}{for(var i = 0, len = gdjs.Game_45Code.GDGuardianSensorRObjects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDGuardianSensorRObjects3[i].putAroundObject((gdjs.Game_45Code.GDGuardianObjects3.length !== 0 ? gdjs.Game_45Code.GDGuardianObjects3[0] : null), 400, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Guardian"), gdjs.Game_45Code.GDGuardianObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects3Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDGuardianObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDPlayerObjects3 */
{gdjs.evtTools.sound.playSound(runtimeScene, "dead.mp3", false, 100, 1);
}{for(var i = 0, len = gdjs.Game_45Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDPlayerObjects3[i].setPosition(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("CheckpointX")),gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("CheckpointY")));
}
}{for(var i = 0, len = gdjs.Game_45Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDPlayerObjects3[i].returnVariable(gdjs.Game_45Code.GDPlayerObjects3[i].getVariables().getFromIndex(1)).sub(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Guardian"), gdjs.Game_45Code.GDGuardianObjects3);
gdjs.copyArray(runtimeScene.getObjects("PlayerHb"), gdjs.Game_45Code.GDPlayerHbObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDGuardianObjects3Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerHbObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDGuardianObjects3.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDGuardianObjects3[i].getVariableNumber(gdjs.Game_45Code.GDGuardianObjects3[i].getVariables().getFromIndex(2)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDGuardianObjects3[k] = gdjs.Game_45Code.GDGuardianObjects3[i];
        ++k;
    }
}
gdjs.Game_45Code.GDGuardianObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14383500);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDGuardianObjects3 */
{for(var i = 0, len = gdjs.Game_45Code.GDGuardianObjects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDGuardianObjects3[i].getBehavior("Flash").Flash(0.2, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.Game_45Code.eventsList8(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Guardian"), gdjs.Game_45Code.GDGuardianObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDGuardianObjects2.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDGuardianObjects2[i].getVariableNumber(gdjs.Game_45Code.GDGuardianObjects2[i].getVariables().getFromIndex(2)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDGuardianObjects2[k] = gdjs.Game_45Code.GDGuardianObjects2[i];
        ++k;
    }
}
gdjs.Game_45Code.GDGuardianObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14386124);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Game_45Code.eventsList9(runtimeScene);} //End of subevents
}

}


};gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Game_45Code.GDPlayerObjects3});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDGuardianSensorL2Objects3Objects = Hashtable.newFrom({"GuardianSensorL2": gdjs.Game_45Code.GDGuardianSensorL2Objects3});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Game_45Code.GDPlayerObjects3});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDGuardianSensorR2Objects3Objects = Hashtable.newFrom({"GuardianSensorR2": gdjs.Game_45Code.GDGuardianSensorR2Objects3});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDGuardian2Objects3Objects = Hashtable.newFrom({"Guardian2": gdjs.Game_45Code.GDGuardian2Objects3});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Game_45Code.GDPlayerObjects3});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDGuardian2Objects3Objects = Hashtable.newFrom({"Guardian2": gdjs.Game_45Code.GDGuardian2Objects3});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Game_45Code.GDPlayerObjects3});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Game_45Code.GDPlayerObjects3});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDGuardian2Objects3Objects = Hashtable.newFrom({"Guardian2": gdjs.Game_45Code.GDGuardian2Objects3});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDGuardian2Objects3Objects = Hashtable.newFrom({"Guardian2": gdjs.Game_45Code.GDGuardian2Objects3});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerHbObjects3Objects = Hashtable.newFrom({"PlayerHb": gdjs.Game_45Code.GDPlayerHbObjects3});
gdjs.Game_45Code.eventsList11 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.Game_45Code.GDGuardian2Objects3, gdjs.Game_45Code.GDGuardian2Objects4);

{for(var i = 0, len = gdjs.Game_45Code.GDGuardian2Objects4.length ;i < len;++i) {
    gdjs.Game_45Code.GDGuardian2Objects4[i].returnVariable(gdjs.Game_45Code.GDGuardian2Objects4[i].getVariables().getFromIndex(0)).sub(1);
}
}}

}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.Game_45Code.GDGuardian2Objects3 */
{for(var i = 0, len = gdjs.Game_45Code.GDGuardian2Objects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDGuardian2Objects3[i].returnVariable(gdjs.Game_45Code.GDGuardian2Objects3[i].getVariables().getFromIndex(2)).setNumber(1);
}
}}

}


};gdjs.Game_45Code.eventsList12 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Game_45Code.GDGuardian2Objects2, gdjs.Game_45Code.GDGuardian2Objects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDGuardian2Objects3.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDGuardian2Objects3[i].getVariableString(gdjs.Game_45Code.GDGuardian2Objects3[i].getVariables().getFromIndex(1)) == "left" ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDGuardian2Objects3[k] = gdjs.Game_45Code.GDGuardian2Objects3[i];
        ++k;
    }
}
gdjs.Game_45Code.GDGuardian2Objects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDGuardian2Objects3 */
gdjs.copyArray(runtimeScene.getObjects("LeftGur2"), gdjs.Game_45Code.GDLeftGur2Objects3);
{gdjs.evtTools.sound.playSound(runtimeScene, "portal-gun-limbo.mp3", false, 100, 1);
}{for(var i = 0, len = gdjs.Game_45Code.GDGuardian2Objects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDGuardian2Objects3[i].setX((( gdjs.Game_45Code.GDLeftGur2Objects3.length === 0 ) ? 0 :gdjs.Game_45Code.GDLeftGur2Objects3[0].getPointX("")));
}
}}

}


{

gdjs.copyArray(gdjs.Game_45Code.GDGuardian2Objects2, gdjs.Game_45Code.GDGuardian2Objects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDGuardian2Objects3.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDGuardian2Objects3[i].getVariableString(gdjs.Game_45Code.GDGuardian2Objects3[i].getVariables().getFromIndex(1)) == "right" ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDGuardian2Objects3[k] = gdjs.Game_45Code.GDGuardian2Objects3[i];
        ++k;
    }
}
gdjs.Game_45Code.GDGuardian2Objects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDGuardian2Objects3 */
gdjs.copyArray(runtimeScene.getObjects("RightGur2"), gdjs.Game_45Code.GDRightGur2Objects3);
{gdjs.evtTools.sound.playSound(runtimeScene, "portal-gun-limbo.mp3", false, 100, 1);
}{for(var i = 0, len = gdjs.Game_45Code.GDGuardian2Objects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDGuardian2Objects3[i].setX((( gdjs.Game_45Code.GDRightGur2Objects3.length === 0 ) ? 0 :gdjs.Game_45Code.GDRightGur2Objects3[0].getPointX("")));
}
}}

}


{

gdjs.copyArray(gdjs.Game_45Code.GDGuardian2Objects2, gdjs.Game_45Code.GDGuardian2Objects3);

gdjs.copyArray(runtimeScene.getObjects("LeftGur2"), gdjs.Game_45Code.GDLeftGur2Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDGuardian2Objects3.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDGuardian2Objects3[i].getX() == (( gdjs.Game_45Code.GDLeftGur2Objects3.length === 0 ) ? 0 :gdjs.Game_45Code.GDLeftGur2Objects3[0].getPointX("")) ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDGuardian2Objects3[k] = gdjs.Game_45Code.GDGuardian2Objects3[i];
        ++k;
    }
}
gdjs.Game_45Code.GDGuardian2Objects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDGuardian2Objects3 */
{for(var i = 0, len = gdjs.Game_45Code.GDGuardian2Objects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDGuardian2Objects3[i].returnVariable(gdjs.Game_45Code.GDGuardian2Objects3[i].getVariables().getFromIndex(1)).setString("right");
}
}{for(var i = 0, len = gdjs.Game_45Code.GDGuardian2Objects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDGuardian2Objects3[i].returnVariable(gdjs.Game_45Code.GDGuardian2Objects3[i].getVariables().getFromIndex(2)).setNumber(0);
}
}}

}


{

gdjs.copyArray(gdjs.Game_45Code.GDGuardian2Objects2, gdjs.Game_45Code.GDGuardian2Objects3);

gdjs.copyArray(runtimeScene.getObjects("RightGur2"), gdjs.Game_45Code.GDRightGur2Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDGuardian2Objects3.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDGuardian2Objects3[i].getX() == (( gdjs.Game_45Code.GDRightGur2Objects3.length === 0 ) ? 0 :gdjs.Game_45Code.GDRightGur2Objects3[0].getPointX("")) ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDGuardian2Objects3[k] = gdjs.Game_45Code.GDGuardian2Objects3[i];
        ++k;
    }
}
gdjs.Game_45Code.GDGuardian2Objects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDGuardian2Objects3 */
{for(var i = 0, len = gdjs.Game_45Code.GDGuardian2Objects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDGuardian2Objects3[i].returnVariable(gdjs.Game_45Code.GDGuardian2Objects3[i].getVariables().getFromIndex(1)).setString("left");
}
}{for(var i = 0, len = gdjs.Game_45Code.GDGuardian2Objects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDGuardian2Objects3[i].returnVariable(gdjs.Game_45Code.GDGuardian2Objects3[i].getVariables().getFromIndex(2)).setNumber(0);
}
}}

}


{

/* Reuse gdjs.Game_45Code.GDGuardian2Objects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDGuardian2Objects2.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDGuardian2Objects2[i].getVariableNumber(gdjs.Game_45Code.GDGuardian2Objects2[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDGuardian2Objects2[k] = gdjs.Game_45Code.GDGuardian2Objects2[i];
        ++k;
    }
}
gdjs.Game_45Code.GDGuardian2Objects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDGuardian2Objects2 */
gdjs.copyArray(runtimeScene.getObjects("GuardianSensorL2"), gdjs.Game_45Code.GDGuardianSensorL2Objects2);
gdjs.copyArray(runtimeScene.getObjects("GuardianSensorR2"), gdjs.Game_45Code.GDGuardianSensorR2Objects2);
{for(var i = 0, len = gdjs.Game_45Code.GDGuardian2Objects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDGuardian2Objects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Game_45Code.GDGuardianSensorL2Objects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDGuardianSensorL2Objects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Game_45Code.GDGuardianSensorR2Objects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDGuardianSensorR2Objects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Victory", false);
}}

}


};gdjs.Game_45Code.eventsList13 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("GuardianSensorL2"), gdjs.Game_45Code.GDGuardianSensorL2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects3Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDGuardianSensorL2Objects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Guardian2"), gdjs.Game_45Code.GDGuardian2Objects3);
{for(var i = 0, len = gdjs.Game_45Code.GDGuardian2Objects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDGuardian2Objects3[i].flipX(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GuardianSensorR2"), gdjs.Game_45Code.GDGuardianSensorR2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects3Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDGuardianSensorR2Objects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Guardian2"), gdjs.Game_45Code.GDGuardian2Objects3);
{for(var i = 0, len = gdjs.Game_45Code.GDGuardian2Objects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDGuardian2Objects3[i].flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Guardian2"), gdjs.Game_45Code.GDGuardian2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDGuardian2Objects3Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects3Objects, 600, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDGuardian2Objects3 */
{for(var i = 0, len = gdjs.Game_45Code.GDGuardian2Objects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDGuardian2Objects3[i].setAnimation(3);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Guardian2"), gdjs.Game_45Code.GDGuardian2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDGuardian2Objects3Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects3Objects, 600, true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDGuardian2Objects3.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDGuardian2Objects3[i].hasAnimationEndedLegacy() ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDGuardian2Objects3[k] = gdjs.Game_45Code.GDGuardian2Objects3[i];
        ++k;
    }
}
gdjs.Game_45Code.GDGuardian2Objects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDGuardian2Objects3 */
{for(var i = 0, len = gdjs.Game_45Code.GDGuardian2Objects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDGuardian2Objects3[i].setAnimation(0);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Guardian2"), gdjs.Game_45Code.GDGuardian2Objects3);
gdjs.copyArray(runtimeScene.getObjects("GuardianSensorL2"), gdjs.Game_45Code.GDGuardianSensorL2Objects3);
gdjs.copyArray(runtimeScene.getObjects("GuardianSensorR2"), gdjs.Game_45Code.GDGuardianSensorR2Objects3);
{for(var i = 0, len = gdjs.Game_45Code.GDGuardianSensorL2Objects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDGuardianSensorL2Objects3[i].putAroundObject((gdjs.Game_45Code.GDGuardian2Objects3.length !== 0 ? gdjs.Game_45Code.GDGuardian2Objects3[0] : null), -(400), 0);
}
}{for(var i = 0, len = gdjs.Game_45Code.GDGuardianSensorR2Objects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDGuardianSensorR2Objects3[i].putAroundObject((gdjs.Game_45Code.GDGuardian2Objects3.length !== 0 ? gdjs.Game_45Code.GDGuardian2Objects3[0] : null), 400, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Guardian2"), gdjs.Game_45Code.GDGuardian2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects3Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDGuardian2Objects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Game_45Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDPlayerObjects3[i].setPosition(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("CheckpointX")),gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("CheckpointY")));
}
}{for(var i = 0, len = gdjs.Game_45Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDPlayerObjects3[i].returnVariable(gdjs.Game_45Code.GDPlayerObjects3[i].getVariables().getFromIndex(1)).sub(1);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "dead.mp3", false, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Guardian2"), gdjs.Game_45Code.GDGuardian2Objects3);
gdjs.copyArray(runtimeScene.getObjects("PlayerHb"), gdjs.Game_45Code.GDPlayerHbObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDGuardian2Objects3Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerHbObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDGuardian2Objects3.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDGuardian2Objects3[i].getVariableNumber(gdjs.Game_45Code.GDGuardian2Objects3[i].getVariables().getFromIndex(2)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDGuardian2Objects3[k] = gdjs.Game_45Code.GDGuardian2Objects3[i];
        ++k;
    }
}
gdjs.Game_45Code.GDGuardian2Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14396812);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDGuardian2Objects3 */
{for(var i = 0, len = gdjs.Game_45Code.GDGuardian2Objects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDGuardian2Objects3[i].getBehavior("Flash").Flash(0.2, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.Game_45Code.eventsList11(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Guardian2"), gdjs.Game_45Code.GDGuardian2Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDGuardian2Objects2.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDGuardian2Objects2[i].getVariableNumber(gdjs.Game_45Code.GDGuardian2Objects2[i].getVariables().getFromIndex(2)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDGuardian2Objects2[k] = gdjs.Game_45Code.GDGuardian2Objects2[i];
        ++k;
    }
}
gdjs.Game_45Code.GDGuardian2Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14398988);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Game_45Code.eventsList12(runtimeScene);} //End of subevents
}

}


};gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDEnmObjects2Objects = Hashtable.newFrom({"Enm": gdjs.Game_45Code.GDEnmObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Game_45Code.GDPlayerObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDEnmObjects2Objects = Hashtable.newFrom({"Enm": gdjs.Game_45Code.GDEnmObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Game_45Code.GDPlayerObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDEnmObjects2Objects = Hashtable.newFrom({"Enm": gdjs.Game_45Code.GDEnmObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Game_45Code.GDPlayerObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDEnmObjects2Objects = Hashtable.newFrom({"Enm": gdjs.Game_45Code.GDEnmObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Game_45Code.GDPlayerObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDEnmObjects2Objects = Hashtable.newFrom({"Enm": gdjs.Game_45Code.GDEnmObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerHbObjects2Objects = Hashtable.newFrom({"PlayerHb": gdjs.Game_45Code.GDPlayerHbObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Game_45Code.GDPlayerObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDLavaObjects2Objects = Hashtable.newFrom({"Lava": gdjs.Game_45Code.GDLavaObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDEnmObjects2Objects = Hashtable.newFrom({"Enm": gdjs.Game_45Code.GDEnmObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDLavaObjects2Objects = Hashtable.newFrom({"Lava": gdjs.Game_45Code.GDLavaObjects2});
gdjs.Game_45Code.eventsList14 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Enm"), gdjs.Game_45Code.GDEnmObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDEnmObjects2.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDEnmObjects2[i].getVariableNumber(gdjs.Game_45Code.GDEnmObjects2[i].getVariables().get("SeeYou")) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDEnmObjects2[k] = gdjs.Game_45Code.GDEnmObjects2[i];
        ++k;
    }
}
gdjs.Game_45Code.GDEnmObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDEnmObjects2 */
{for(var i = 0, len = gdjs.Game_45Code.GDEnmObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDEnmObjects2[i].activateBehavior("Pathfinding", false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enm"), gdjs.Game_45Code.GDEnmObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDEnmObjects2.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDEnmObjects2[i].getVariableNumber(gdjs.Game_45Code.GDEnmObjects2[i].getVariables().get("SeeYou")) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDEnmObjects2[k] = gdjs.Game_45Code.GDEnmObjects2[i];
        ++k;
    }
}
gdjs.Game_45Code.GDEnmObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDEnmObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects2);
{for(var i = 0, len = gdjs.Game_45Code.GDEnmObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDEnmObjects2[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.Game_45Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Game_45Code.GDPlayerObjects2[0].getPointX("")) + gdjs.random(50), (( gdjs.Game_45Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Game_45Code.GDPlayerObjects2[0].getPointY("")) + gdjs.random(50));
}
}{for(var i = 0, len = gdjs.Game_45Code.GDEnmObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDEnmObjects2[i].activateBehavior("Pathfinding", true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enm"), gdjs.Game_45Code.GDEnmObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDEnmObjects2Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects, 700, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDEnmObjects2.length;i<l;++i) {
    if ( !(gdjs.Game_45Code.GDEnmObjects2[i].getAnimation() == 2) ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDEnmObjects2[k] = gdjs.Game_45Code.GDEnmObjects2[i];
        ++k;
    }
}
gdjs.Game_45Code.GDEnmObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDEnmObjects2 */
{for(var i = 0, len = gdjs.Game_45Code.GDEnmObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDEnmObjects2[i].returnVariable(gdjs.Game_45Code.GDEnmObjects2[i].getVariables().get("SeeYou")).setNumber(1);
}
}{for(var i = 0, len = gdjs.Game_45Code.GDEnmObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDEnmObjects2[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.Game_45Code.GDEnmObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDEnmObjects2[i].flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enm"), gdjs.Game_45Code.GDEnmObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDEnmObjects2Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects, 700, true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDEnmObjects2.length;i<l;++i) {
    if ( !(gdjs.Game_45Code.GDEnmObjects2[i].getAnimation() == 2) ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDEnmObjects2[k] = gdjs.Game_45Code.GDEnmObjects2[i];
        ++k;
    }
}
gdjs.Game_45Code.GDEnmObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDEnmObjects2 */
{for(var i = 0, len = gdjs.Game_45Code.GDEnmObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDEnmObjects2[i].returnVariable(gdjs.Game_45Code.GDEnmObjects2[i].getVariables().get("SeeYou")).setNumber(0);
}
}{for(var i = 0, len = gdjs.Game_45Code.GDEnmObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDEnmObjects2[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.Game_45Code.GDEnmObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDEnmObjects2[i].flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enm"), gdjs.Game_45Code.GDEnmObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.turnedTowardTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDEnmObjects2Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects, 100, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDEnmObjects2 */
{for(var i = 0, len = gdjs.Game_45Code.GDEnmObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDEnmObjects2[i].flipX(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enm"), gdjs.Game_45Code.GDEnmObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDEnmObjects2Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDPlayerObjects2 */
{gdjs.evtTools.sound.playSound(runtimeScene, "dead.mp3", false, 100, 1);
}{for(var i = 0, len = gdjs.Game_45Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDPlayerObjects2[i].setPosition(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("CheckpointX")),gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("CheckpointY")));
}
}{for(var i = 0, len = gdjs.Game_45Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDPlayerObjects2[i].returnVariable(gdjs.Game_45Code.GDPlayerObjects2[i].getVariables().getFromIndex(1)).sub(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enm"), gdjs.Game_45Code.GDEnmObjects2);
gdjs.copyArray(runtimeScene.getObjects("PlayerHb"), gdjs.Game_45Code.GDPlayerHbObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDEnmObjects2Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerHbObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14412004);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDEnmObjects2 */
{for(var i = 0, len = gdjs.Game_45Code.GDEnmObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDEnmObjects2[i].setAnimation(2);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "zapsplat_explosion_grenade_300m_distance_reverb_ext_25222 (mp3cut.net).mp3", false, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lava"), gdjs.Game_45Code.GDLavaObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDLavaObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDPlayerObjects2 */
{gdjs.evtTools.sound.playSound(runtimeScene, "dead.mp3", false, 100, 1);
}{for(var i = 0, len = gdjs.Game_45Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDPlayerObjects2[i].setPosition(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("CheckpointX")),gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("CheckpointY")));
}
}{for(var i = 0, len = gdjs.Game_45Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDPlayerObjects2[i].returnVariable(gdjs.Game_45Code.GDPlayerObjects2[i].getVariables().getFromIndex(1)).sub(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enm"), gdjs.Game_45Code.GDEnmObjects2);
gdjs.copyArray(runtimeScene.getObjects("Lava"), gdjs.Game_45Code.GDLavaObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDEnmObjects2Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDLavaObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14414708);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDEnmObjects2 */
{for(var i = 0, len = gdjs.Game_45Code.GDEnmObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDEnmObjects2[i].setAnimation(2);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "zapsplat_explosion_grenade_300m_distance_reverb_ext_25222 (mp3cut.net).mp3", false, 50, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enm"), gdjs.Game_45Code.GDEnmObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDEnmObjects2.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDEnmObjects2[i].getAnimation() == 2 ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDEnmObjects2[k] = gdjs.Game_45Code.GDEnmObjects2[i];
        ++k;
    }
}
gdjs.Game_45Code.GDEnmObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDEnmObjects2.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDEnmObjects2[i].hasAnimationEndedLegacy() ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDEnmObjects2[k] = gdjs.Game_45Code.GDEnmObjects2[i];
        ++k;
    }
}
gdjs.Game_45Code.GDEnmObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDEnmObjects2 */
{for(var i = 0, len = gdjs.Game_45Code.GDEnmObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDEnmObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.Game_45Code.eventsList15 = function(runtimeScene) {

{


gdjs.Game_45Code.eventsList10(runtimeScene);
}


{


gdjs.Game_45Code.eventsList13(runtimeScene);
}


{


gdjs.Game_45Code.eventsList14(runtimeScene);
}


};gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Game_45Code.GDPlayerObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDCheckpointObjects2Objects = Hashtable.newFrom({"Checkpoint": gdjs.Game_45Code.GDCheckpointObjects2});
gdjs.Game_45Code.eventsList16 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Checkpoint"), gdjs.Game_45Code.GDCheckpointObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDCheckpointObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDCheckpointObjects2 */
{runtimeScene.getScene().getVariables().get("CheckpointX").setNumber((( gdjs.Game_45Code.GDCheckpointObjects2.length === 0 ) ? 0 :gdjs.Game_45Code.GDCheckpointObjects2[0].getPointX("")));
}{runtimeScene.getScene().getVariables().get("CheckpointY").setNumber((( gdjs.Game_45Code.GDCheckpointObjects2.length === 0 ) ? 0 :gdjs.Game_45Code.GDCheckpointObjects2[0].getPointY("")));
}{for(var i = 0, len = gdjs.Game_45Code.GDCheckpointObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDCheckpointObjects2[i].setAnimation(1);
}
}}

}


};gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Game_45Code.GDPlayerObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDNewObjectObjects2Objects = Hashtable.newFrom({"NewObject": gdjs.Game_45Code.GDNewObjectObjects2});
gdjs.Game_45Code.eventsList17 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("NewObject"), gdjs.Game_45Code.GDNewObjectObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDNewObjectObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) == 1;
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "ScoreBoard-", false);
}}

}


};gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Game_45Code.GDPlayerObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPortalObjects2Objects = Hashtable.newFrom({"Portal": gdjs.Game_45Code.GDPortalObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Game_45Code.GDPlayerObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPortal2Objects2Objects = Hashtable.newFrom({"Portal2": gdjs.Game_45Code.GDPortal2Objects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Game_45Code.GDPlayerObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPortalaObjects2Objects = Hashtable.newFrom({"Portala": gdjs.Game_45Code.GDPortalaObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Game_45Code.GDPlayerObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPortala2Objects2Objects = Hashtable.newFrom({"Portala2": gdjs.Game_45Code.GDPortala2Objects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Game_45Code.GDPlayerObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPortalcObjects2Objects = Hashtable.newFrom({"Portalc": gdjs.Game_45Code.GDPortalcObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Game_45Code.GDPlayerObjects1});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPortalc2Objects1Objects = Hashtable.newFrom({"Portalc2": gdjs.Game_45Code.GDPortalc2Objects1});
gdjs.Game_45Code.eventsList18 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Portal"), gdjs.Game_45Code.GDPortalObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPortalObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14420980);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDPlayerObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Portal2"), gdjs.Game_45Code.GDPortal2Objects2);
{gdjs.evtTools.sound.playSound(runtimeScene, "portalenter.mp3", false, 125, 1);
}{for(var i = 0, len = gdjs.Game_45Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDPlayerObjects2[i].setPosition((( gdjs.Game_45Code.GDPortal2Objects2.length === 0 ) ? 0 :gdjs.Game_45Code.GDPortal2Objects2[0].getPointX("")) + 100,(( gdjs.Game_45Code.GDPortal2Objects2.length === 0 ) ? 0 :gdjs.Game_45Code.GDPortal2Objects2[0].getPointY("")));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Portal2"), gdjs.Game_45Code.GDPortal2Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPortal2Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14422148);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDPlayerObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Portal"), gdjs.Game_45Code.GDPortalObjects2);
{gdjs.evtTools.sound.playSound(runtimeScene, "portalenter.mp3", false, 125, 1);
}{for(var i = 0, len = gdjs.Game_45Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDPlayerObjects2[i].setPosition((( gdjs.Game_45Code.GDPortalObjects2.length === 0 ) ? 0 :gdjs.Game_45Code.GDPortalObjects2[0].getPointX("")) + 100,(( gdjs.Game_45Code.GDPortalObjects2.length === 0 ) ? 0 :gdjs.Game_45Code.GDPortalObjects2[0].getPointY("")));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Portala"), gdjs.Game_45Code.GDPortalaObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPortalaObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14423372);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDPlayerObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Portala2"), gdjs.Game_45Code.GDPortala2Objects2);
{gdjs.evtTools.sound.playSound(runtimeScene, "portalenter.mp3", false, 125, 1);
}{for(var i = 0, len = gdjs.Game_45Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDPlayerObjects2[i].setPosition((( gdjs.Game_45Code.GDPortala2Objects2.length === 0 ) ? 0 :gdjs.Game_45Code.GDPortala2Objects2[0].getPointX("")) + 100,(( gdjs.Game_45Code.GDPortala2Objects2.length === 0 ) ? 0 :gdjs.Game_45Code.GDPortala2Objects2[0].getPointY("")));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Portala2"), gdjs.Game_45Code.GDPortala2Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPortala2Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14424716);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDPlayerObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Portala"), gdjs.Game_45Code.GDPortalaObjects2);
{gdjs.evtTools.sound.playSound(runtimeScene, "portalenter.mp3", false, 125, 1);
}{for(var i = 0, len = gdjs.Game_45Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDPlayerObjects2[i].setPosition((( gdjs.Game_45Code.GDPortalaObjects2.length === 0 ) ? 0 :gdjs.Game_45Code.GDPortalaObjects2[0].getPointX("")) + 100,(( gdjs.Game_45Code.GDPortalaObjects2.length === 0 ) ? 0 :gdjs.Game_45Code.GDPortalaObjects2[0].getPointY("")));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Portalc"), gdjs.Game_45Code.GDPortalcObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPortalcObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14426020);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDPlayerObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Portalc2"), gdjs.Game_45Code.GDPortalc2Objects2);
{gdjs.evtTools.sound.playSound(runtimeScene, "portalenter.mp3", false, 125, 1);
}{for(var i = 0, len = gdjs.Game_45Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDPlayerObjects2[i].setPosition((( gdjs.Game_45Code.GDPortalc2Objects2.length === 0 ) ? 0 :gdjs.Game_45Code.GDPortalc2Objects2[0].getPointX("")) + 100,(( gdjs.Game_45Code.GDPortalc2Objects2.length === 0 ) ? 0 :gdjs.Game_45Code.GDPortalc2Objects2[0].getPointY("")));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Portalc2"), gdjs.Game_45Code.GDPortalc2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects1Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPortalc2Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14427772);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDPlayerObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Portalc"), gdjs.Game_45Code.GDPortalcObjects1);
{gdjs.evtTools.sound.playSound(runtimeScene, "portalenter.mp3", false, 125, 1);
}{for(var i = 0, len = gdjs.Game_45Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Game_45Code.GDPlayerObjects1[i].setPosition((( gdjs.Game_45Code.GDPortalcObjects1.length === 0 ) ? 0 :gdjs.Game_45Code.GDPortalcObjects1[0].getPointX("")) + 100,(( gdjs.Game_45Code.GDPortalcObjects1.length === 0 ) ? 0 :gdjs.Game_45Code.GDPortalcObjects1[0].getPointY("")));
}
}}

}


};gdjs.Game_45Code.eventsList19 = function(runtimeScene) {

{


gdjs.Game_45Code.eventsList16(runtimeScene);
}


{


gdjs.Game_45Code.eventsList17(runtimeScene);
}


{


gdjs.Game_45Code.eventsList18(runtimeScene);
}


};gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDMovFloatR2Objects2Objects = Hashtable.newFrom({"MovFloatR2": gdjs.Game_45Code.GDMovFloatR2Objects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDDownObjects2Objects = Hashtable.newFrom({"Down": gdjs.Game_45Code.GDDownObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDMovFloatR2Objects2Objects = Hashtable.newFrom({"MovFloatR2": gdjs.Game_45Code.GDMovFloatR2Objects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDUpObjects2Objects = Hashtable.newFrom({"Up": gdjs.Game_45Code.GDUpObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDMovFloatR3Objects2Objects = Hashtable.newFrom({"MovFloatR3": gdjs.Game_45Code.GDMovFloatR3Objects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDRightObjects2Objects = Hashtable.newFrom({"Right": gdjs.Game_45Code.GDRightObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDMovFloatR3Objects2Objects = Hashtable.newFrom({"MovFloatR3": gdjs.Game_45Code.GDMovFloatR3Objects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDLeftObjects2Objects = Hashtable.newFrom({"Left": gdjs.Game_45Code.GDLeftObjects2});
gdjs.Game_45Code.eventsList20 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("MovFloatR2"), gdjs.Game_45Code.GDMovFloatR2Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDMovFloatR2Objects2.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDMovFloatR2Objects2[i].getVariableString(gdjs.Game_45Code.GDMovFloatR2Objects2[i].getVariables().getFromIndex(0)) == "up" ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDMovFloatR2Objects2[k] = gdjs.Game_45Code.GDMovFloatR2Objects2[i];
        ++k;
    }
}
gdjs.Game_45Code.GDMovFloatR2Objects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDMovFloatR2Objects2 */
{for(var i = 0, len = gdjs.Game_45Code.GDMovFloatR2Objects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDMovFloatR2Objects2[i].addForce(0, -(150), 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("MovFloatR2"), gdjs.Game_45Code.GDMovFloatR2Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDMovFloatR2Objects2.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDMovFloatR2Objects2[i].getVariableString(gdjs.Game_45Code.GDMovFloatR2Objects2[i].getVariables().getFromIndex(0)) == "down" ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDMovFloatR2Objects2[k] = gdjs.Game_45Code.GDMovFloatR2Objects2[i];
        ++k;
    }
}
gdjs.Game_45Code.GDMovFloatR2Objects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDMovFloatR2Objects2 */
{for(var i = 0, len = gdjs.Game_45Code.GDMovFloatR2Objects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDMovFloatR2Objects2[i].addForce(0, 150, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Down"), gdjs.Game_45Code.GDDownObjects2);
gdjs.copyArray(runtimeScene.getObjects("MovFloatR2"), gdjs.Game_45Code.GDMovFloatR2Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDMovFloatR2Objects2Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDDownObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDMovFloatR2Objects2 */
{for(var i = 0, len = gdjs.Game_45Code.GDMovFloatR2Objects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDMovFloatR2Objects2[i].returnVariable(gdjs.Game_45Code.GDMovFloatR2Objects2[i].getVariables().getFromIndex(0)).setString("down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("MovFloatR2"), gdjs.Game_45Code.GDMovFloatR2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Up"), gdjs.Game_45Code.GDUpObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDMovFloatR2Objects2Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDUpObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDMovFloatR2Objects2 */
{for(var i = 0, len = gdjs.Game_45Code.GDMovFloatR2Objects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDMovFloatR2Objects2[i].returnVariable(gdjs.Game_45Code.GDMovFloatR2Objects2[i].getVariables().getFromIndex(0)).setString("up");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("MovFloatR3"), gdjs.Game_45Code.GDMovFloatR3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Right"), gdjs.Game_45Code.GDRightObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDMovFloatR3Objects2Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDRightObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDMovFloatR3Objects2 */
{for(var i = 0, len = gdjs.Game_45Code.GDMovFloatR3Objects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDMovFloatR3Objects2[i].returnVariable(gdjs.Game_45Code.GDMovFloatR3Objects2[i].getVariables().getFromIndex(0)).setString("right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Left"), gdjs.Game_45Code.GDLeftObjects2);
gdjs.copyArray(runtimeScene.getObjects("MovFloatR3"), gdjs.Game_45Code.GDMovFloatR3Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDMovFloatR3Objects2Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDLeftObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDMovFloatR3Objects2 */
{for(var i = 0, len = gdjs.Game_45Code.GDMovFloatR3Objects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDMovFloatR3Objects2[i].returnVariable(gdjs.Game_45Code.GDMovFloatR3Objects2[i].getVariables().getFromIndex(0)).setString("left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("MovFloatR3"), gdjs.Game_45Code.GDMovFloatR3Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDMovFloatR3Objects2.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDMovFloatR3Objects2[i].getVariableString(gdjs.Game_45Code.GDMovFloatR3Objects2[i].getVariables().getFromIndex(0)) == "right" ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDMovFloatR3Objects2[k] = gdjs.Game_45Code.GDMovFloatR3Objects2[i];
        ++k;
    }
}
gdjs.Game_45Code.GDMovFloatR3Objects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDMovFloatR3Objects2 */
{for(var i = 0, len = gdjs.Game_45Code.GDMovFloatR3Objects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDMovFloatR3Objects2[i].addForce(150, 0, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("MovFloatR3"), gdjs.Game_45Code.GDMovFloatR3Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDMovFloatR3Objects1.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDMovFloatR3Objects1[i].getVariableString(gdjs.Game_45Code.GDMovFloatR3Objects1[i].getVariables().getFromIndex(0)) == "left" ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDMovFloatR3Objects1[k] = gdjs.Game_45Code.GDMovFloatR3Objects1[i];
        ++k;
    }
}
gdjs.Game_45Code.GDMovFloatR3Objects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDMovFloatR3Objects1 */
{for(var i = 0, len = gdjs.Game_45Code.GDMovFloatR3Objects1.length ;i < len;++i) {
    gdjs.Game_45Code.GDMovFloatR3Objects1[i].addForce(-(150), 0, 0);
}
}}

}


};gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Game_45Code.GDPlayerObjects3});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDFlameHbObjects3Objects = Hashtable.newFrom({"FlameHb": gdjs.Game_45Code.GDFlameHbObjects3});
gdjs.Game_45Code.eventsList21 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Flame"), gdjs.Game_45Code.GDFlameObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDFlameObjects3.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDFlameObjects3[i].getAnimationFrame() == 4 ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDFlameObjects3[k] = gdjs.Game_45Code.GDFlameObjects3[i];
        ++k;
    }
}
gdjs.Game_45Code.GDFlameObjects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("FlameHb"), gdjs.Game_45Code.GDFlameHbObjects3);
{for(var i = 0, len = gdjs.Game_45Code.GDFlameHbObjects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDFlameHbObjects3[i].putAround(20285, 750, 0, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Flame"), gdjs.Game_45Code.GDFlameObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDFlameObjects3.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDFlameObjects3[i].getAnimationFrame() == 11 ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDFlameObjects3[k] = gdjs.Game_45Code.GDFlameObjects3[i];
        ++k;
    }
}
gdjs.Game_45Code.GDFlameObjects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("FlameHb"), gdjs.Game_45Code.GDFlameHbObjects3);
gdjs.copyArray(runtimeScene.getObjects("SaveHb"), gdjs.Game_45Code.GDSaveHbObjects3);
{for(var i = 0, len = gdjs.Game_45Code.GDFlameHbObjects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDFlameHbObjects3[i].putAroundObject((gdjs.Game_45Code.GDSaveHbObjects3.length !== 0 ? gdjs.Game_45Code.GDSaveHbObjects3[0] : null), 0, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("FlameHb"), gdjs.Game_45Code.GDFlameHbObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects3Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDFlameHbObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Game_45Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDPlayerObjects3[i].setPosition(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("CheckpointX")),gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("CheckpointY")));
}
}{for(var i = 0, len = gdjs.Game_45Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDPlayerObjects3[i].returnVariable(gdjs.Game_45Code.GDPlayerObjects3[i].getVariables().getFromIndex(1)).sub(1);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "dead.mp3", false, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Flame3"), gdjs.Game_45Code.GDFlame3Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDFlame3Objects3.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDFlame3Objects3[i].hasAnimationEndedLegacy() ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDFlame3Objects3[k] = gdjs.Game_45Code.GDFlame3Objects3[i];
        ++k;
    }
}
gdjs.Game_45Code.GDFlame3Objects3.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 2);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Flame"), gdjs.Game_45Code.GDFlameObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDFlameObjects2.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDFlameObjects2[i].getAnimationFrame() == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDFlameObjects2[k] = gdjs.Game_45Code.GDFlameObjects2[i];
        ++k;
    }
}
gdjs.Game_45Code.GDFlameObjects2.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "smartsound_WEAPONS_FLAMETHROWER_Medium_Heavy_Single_01.mp3", 2, false, 25, 1);
}}

}


};gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Game_45Code.GDPlayerObjects3});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDFlameHb2Objects3Objects = Hashtable.newFrom({"FlameHb2": gdjs.Game_45Code.GDFlameHb2Objects3});
gdjs.Game_45Code.eventsList22 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Flame2"), gdjs.Game_45Code.GDFlame2Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDFlame2Objects3.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDFlame2Objects3[i].getAnimationFrame() == 4 ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDFlame2Objects3[k] = gdjs.Game_45Code.GDFlame2Objects3[i];
        ++k;
    }
}
gdjs.Game_45Code.GDFlame2Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("FlameHb2"), gdjs.Game_45Code.GDFlameHb2Objects3);
{for(var i = 0, len = gdjs.Game_45Code.GDFlameHb2Objects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDFlameHb2Objects3[i].putAround(13128, 7050, 0, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Flame2"), gdjs.Game_45Code.GDFlame2Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDFlame2Objects3.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDFlame2Objects3[i].getAnimationFrame() == 11 ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDFlame2Objects3[k] = gdjs.Game_45Code.GDFlame2Objects3[i];
        ++k;
    }
}
gdjs.Game_45Code.GDFlame2Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("FlameHb2"), gdjs.Game_45Code.GDFlameHb2Objects3);
gdjs.copyArray(runtimeScene.getObjects("SaveHb"), gdjs.Game_45Code.GDSaveHbObjects3);
{for(var i = 0, len = gdjs.Game_45Code.GDFlameHb2Objects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDFlameHb2Objects3[i].putAroundObject((gdjs.Game_45Code.GDSaveHbObjects3.length !== 0 ? gdjs.Game_45Code.GDSaveHbObjects3[0] : null), 0, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("FlameHb2"), gdjs.Game_45Code.GDFlameHb2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects3Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDFlameHb2Objects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Game_45Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDPlayerObjects3[i].setPosition(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("CheckpointX")),gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("CheckpointY")));
}
}{for(var i = 0, len = gdjs.Game_45Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDPlayerObjects3[i].returnVariable(gdjs.Game_45Code.GDPlayerObjects3[i].getVariables().getFromIndex(1)).sub(1);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "dead.mp3", false, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Flame3"), gdjs.Game_45Code.GDFlame3Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDFlame3Objects3.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDFlame3Objects3[i].hasAnimationEndedLegacy() ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDFlame3Objects3[k] = gdjs.Game_45Code.GDFlame3Objects3[i];
        ++k;
    }
}
gdjs.Game_45Code.GDFlame3Objects3.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 4);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Flame2"), gdjs.Game_45Code.GDFlame2Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDFlame2Objects2.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDFlame2Objects2[i].getAnimationFrame() == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDFlame2Objects2[k] = gdjs.Game_45Code.GDFlame2Objects2[i];
        ++k;
    }
}
gdjs.Game_45Code.GDFlame2Objects2.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "smartsound_WEAPONS_FLAMETHROWER_Medium_Heavy_Single_01.mp3", 4, false, 25, 1);
}}

}


};gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Game_45Code.GDPlayerObjects3});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDFlameHb3Objects3Objects = Hashtable.newFrom({"FlameHb3": gdjs.Game_45Code.GDFlameHb3Objects3});
gdjs.Game_45Code.eventsList23 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Flame3"), gdjs.Game_45Code.GDFlame3Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDFlame3Objects3.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDFlame3Objects3[i].getAnimationFrame() == 4 ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDFlame3Objects3[k] = gdjs.Game_45Code.GDFlame3Objects3[i];
        ++k;
    }
}
gdjs.Game_45Code.GDFlame3Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("FlameHb3"), gdjs.Game_45Code.GDFlameHb3Objects3);
{for(var i = 0, len = gdjs.Game_45Code.GDFlameHb3Objects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDFlameHb3Objects3[i].putAround(14930, 7050, 0, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Flame3"), gdjs.Game_45Code.GDFlame3Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDFlame3Objects3.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDFlame3Objects3[i].getAnimationFrame() == 11 ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDFlame3Objects3[k] = gdjs.Game_45Code.GDFlame3Objects3[i];
        ++k;
    }
}
gdjs.Game_45Code.GDFlame3Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("FlameHb3"), gdjs.Game_45Code.GDFlameHb3Objects3);
gdjs.copyArray(runtimeScene.getObjects("SaveHb"), gdjs.Game_45Code.GDSaveHbObjects3);
{for(var i = 0, len = gdjs.Game_45Code.GDFlameHb3Objects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDFlameHb3Objects3[i].putAroundObject((gdjs.Game_45Code.GDSaveHbObjects3.length !== 0 ? gdjs.Game_45Code.GDSaveHbObjects3[0] : null), 0, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("FlameHb3"), gdjs.Game_45Code.GDFlameHb3Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects3Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDFlameHb3Objects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Game_45Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDPlayerObjects3[i].setPosition(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("CheckpointX")),gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("CheckpointY")));
}
}{for(var i = 0, len = gdjs.Game_45Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Game_45Code.GDPlayerObjects3[i].returnVariable(gdjs.Game_45Code.GDPlayerObjects3[i].getVariables().getFromIndex(1)).sub(1);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "dead.mp3", false, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Flame3"), gdjs.Game_45Code.GDFlame3Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDFlame3Objects3.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDFlame3Objects3[i].hasAnimationEndedLegacy() ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDFlame3Objects3[k] = gdjs.Game_45Code.GDFlame3Objects3[i];
        ++k;
    }
}
gdjs.Game_45Code.GDFlame3Objects3.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 5);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Flame3"), gdjs.Game_45Code.GDFlame3Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDFlame3Objects2.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDFlame3Objects2[i].getAnimationFrame() == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDFlame3Objects2[k] = gdjs.Game_45Code.GDFlame3Objects2[i];
        ++k;
    }
}
gdjs.Game_45Code.GDFlame3Objects2.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "smartsound_WEAPONS_FLAMETHROWER_Medium_Heavy_Single_01.mp3", 5, false, 25, 1);
}}

}


};gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Game_45Code.GDPlayerObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDSpikeObjects2Objects = Hashtable.newFrom({"Spike": gdjs.Game_45Code.GDSpikeObjects2});
gdjs.Game_45Code.eventsList24 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Spike"), gdjs.Game_45Code.GDSpikeObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDSpikeObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Game_45Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDPlayerObjects2[i].setPosition(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("CheckpointX")),gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("CheckpointY")));
}
}{for(var i = 0, len = gdjs.Game_45Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDPlayerObjects2[i].returnVariable(gdjs.Game_45Code.GDPlayerObjects2[i].getVariables().getFromIndex(1)).sub(1);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "dead.mp3", false, 100, 1);
}}

}


};gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDSawObjects2Objects = Hashtable.newFrom({"Saw": gdjs.Game_45Code.GDSawObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDUpObjects2Objects = Hashtable.newFrom({"Up": gdjs.Game_45Code.GDUpObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDSawObjects2Objects = Hashtable.newFrom({"Saw": gdjs.Game_45Code.GDSawObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDDownObjects2Objects = Hashtable.newFrom({"Down": gdjs.Game_45Code.GDDownObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Game_45Code.GDPlayerObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDSawObjects2Objects = Hashtable.newFrom({"Saw": gdjs.Game_45Code.GDSawObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDSaw2Objects2Objects = Hashtable.newFrom({"Saw2": gdjs.Game_45Code.GDSaw2Objects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDRightObjects2Objects = Hashtable.newFrom({"Right": gdjs.Game_45Code.GDRightObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDSaw2Objects2Objects = Hashtable.newFrom({"Saw2": gdjs.Game_45Code.GDSaw2Objects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDLeftObjects2Objects = Hashtable.newFrom({"Left": gdjs.Game_45Code.GDLeftObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Game_45Code.GDPlayerObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDSaw2Objects2Objects = Hashtable.newFrom({"Saw2": gdjs.Game_45Code.GDSaw2Objects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Game_45Code.GDPlayerObjects1});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDSawObjects1Objects = Hashtable.newFrom({"Saw": gdjs.Game_45Code.GDSawObjects1});
gdjs.Game_45Code.eventsList25 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Saw"), gdjs.Game_45Code.GDSawObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDSawObjects2.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDSawObjects2[i].getVariableString(gdjs.Game_45Code.GDSawObjects2[i].getVariables().getFromIndex(0)) == "down" ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDSawObjects2[k] = gdjs.Game_45Code.GDSawObjects2[i];
        ++k;
    }
}
gdjs.Game_45Code.GDSawObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDSawObjects2 */
{for(var i = 0, len = gdjs.Game_45Code.GDSawObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDSawObjects2[i].addForce(0, 200, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Saw"), gdjs.Game_45Code.GDSawObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDSawObjects2.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDSawObjects2[i].getVariableString(gdjs.Game_45Code.GDSawObjects2[i].getVariables().getFromIndex(0)) == "up" ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDSawObjects2[k] = gdjs.Game_45Code.GDSawObjects2[i];
        ++k;
    }
}
gdjs.Game_45Code.GDSawObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDSawObjects2 */
{for(var i = 0, len = gdjs.Game_45Code.GDSawObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDSawObjects2[i].addForce(0, -(200), 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Saw"), gdjs.Game_45Code.GDSawObjects2);
gdjs.copyArray(runtimeScene.getObjects("Up"), gdjs.Game_45Code.GDUpObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDSawObjects2Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDUpObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDSawObjects2 */
{for(var i = 0, len = gdjs.Game_45Code.GDSawObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDSawObjects2[i].returnVariable(gdjs.Game_45Code.GDSawObjects2[i].getVariables().getFromIndex(0)).setString("up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Down"), gdjs.Game_45Code.GDDownObjects2);
gdjs.copyArray(runtimeScene.getObjects("Saw"), gdjs.Game_45Code.GDSawObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDSawObjects2Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDDownObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDSawObjects2 */
{for(var i = 0, len = gdjs.Game_45Code.GDSawObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDSawObjects2[i].returnVariable(gdjs.Game_45Code.GDSawObjects2[i].getVariables().getFromIndex(0)).setString("down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Saw"), gdjs.Game_45Code.GDSawObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDSawObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDPlayerObjects2 */
{gdjs.evtTools.sound.playSound(runtimeScene, "dead.mp3", false, 100, 1);
}{for(var i = 0, len = gdjs.Game_45Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDPlayerObjects2[i].setPosition(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("CheckpointX")),gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("CheckpointY")));
}
}{for(var i = 0, len = gdjs.Game_45Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDPlayerObjects2[i].returnVariable(gdjs.Game_45Code.GDPlayerObjects2[i].getVariables().getFromIndex(1)).sub(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Right"), gdjs.Game_45Code.GDRightObjects2);
gdjs.copyArray(runtimeScene.getObjects("Saw2"), gdjs.Game_45Code.GDSaw2Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDSaw2Objects2Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDRightObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDSaw2Objects2 */
{for(var i = 0, len = gdjs.Game_45Code.GDSaw2Objects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDSaw2Objects2[i].returnVariable(gdjs.Game_45Code.GDSaw2Objects2[i].getVariables().getFromIndex(1)).setString("right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Left"), gdjs.Game_45Code.GDLeftObjects2);
gdjs.copyArray(runtimeScene.getObjects("Saw2"), gdjs.Game_45Code.GDSaw2Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDSaw2Objects2Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDLeftObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDSaw2Objects2 */
{for(var i = 0, len = gdjs.Game_45Code.GDSaw2Objects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDSaw2Objects2[i].returnVariable(gdjs.Game_45Code.GDSaw2Objects2[i].getVariables().getFromIndex(1)).setString("left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Saw2"), gdjs.Game_45Code.GDSaw2Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDSaw2Objects2.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDSaw2Objects2[i].getVariableString(gdjs.Game_45Code.GDSaw2Objects2[i].getVariables().getFromIndex(1)) == "right" ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDSaw2Objects2[k] = gdjs.Game_45Code.GDSaw2Objects2[i];
        ++k;
    }
}
gdjs.Game_45Code.GDSaw2Objects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDSaw2Objects2 */
{for(var i = 0, len = gdjs.Game_45Code.GDSaw2Objects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDSaw2Objects2[i].addForce(150, 0, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Saw2"), gdjs.Game_45Code.GDSaw2Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_45Code.GDSaw2Objects2.length;i<l;++i) {
    if ( gdjs.Game_45Code.GDSaw2Objects2[i].getVariableString(gdjs.Game_45Code.GDSaw2Objects2[i].getVariables().getFromIndex(1)) == "left" ) {
        isConditionTrue_0 = true;
        gdjs.Game_45Code.GDSaw2Objects2[k] = gdjs.Game_45Code.GDSaw2Objects2[i];
        ++k;
    }
}
gdjs.Game_45Code.GDSaw2Objects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDSaw2Objects2 */
{for(var i = 0, len = gdjs.Game_45Code.GDSaw2Objects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDSaw2Objects2[i].addForce(-(150), 0, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Saw2"), gdjs.Game_45Code.GDSaw2Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDSaw2Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Game_45Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDPlayerObjects2[i].setPosition(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("CheckpointX")),gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("CheckpointY")));
}
}{for(var i = 0, len = gdjs.Game_45Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDPlayerObjects2[i].returnVariable(gdjs.Game_45Code.GDPlayerObjects2[i].getVariables().getFromIndex(1)).sub(1);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "dead.mp3", false, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Saw"), gdjs.Game_45Code.GDSawObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects1Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDSawObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Game_45Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.Game_45Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Game_45Code.GDPlayerObjects1[i].setPosition(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("CheckpointX")),gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("CheckpointY")));
}
}{for(var i = 0, len = gdjs.Game_45Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Game_45Code.GDPlayerObjects1[i].returnVariable(gdjs.Game_45Code.GDPlayerObjects1[i].getVariables().getFromIndex(1)).sub(1);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "dead.mp3", false, 100, 1);
}}

}


};gdjs.Game_45Code.eventsList26 = function(runtimeScene) {

{


gdjs.Game_45Code.eventsList21(runtimeScene);
}


{


gdjs.Game_45Code.eventsList22(runtimeScene);
}


{


gdjs.Game_45Code.eventsList23(runtimeScene);
}


{


gdjs.Game_45Code.eventsList24(runtimeScene);
}


{


gdjs.Game_45Code.eventsList25(runtimeScene);
}


};gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Game_45Code.GDPlayerObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDStoryPointObjects2Objects = Hashtable.newFrom({"StoryPoint": gdjs.Game_45Code.GDStoryPointObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Game_45Code.GDPlayerObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDStoryPointObjects2Objects = Hashtable.newFrom({"StoryPoint": gdjs.Game_45Code.GDStoryPointObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Game_45Code.GDPlayerObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDEwokTextObjects2Objects = Hashtable.newFrom({"EwokText": gdjs.Game_45Code.GDEwokTextObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Game_45Code.GDPlayerObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDEwokTextObjects2Objects = Hashtable.newFrom({"EwokText": gdjs.Game_45Code.GDEwokTextObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Game_45Code.GDPlayerObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDEwokText2Objects2Objects = Hashtable.newFrom({"EwokText2": gdjs.Game_45Code.GDEwokText2Objects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Game_45Code.GDPlayerObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDEwokText2Objects2Objects = Hashtable.newFrom({"EwokText2": gdjs.Game_45Code.GDEwokText2Objects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Game_45Code.GDPlayerObjects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDEwokText3Objects2Objects = Hashtable.newFrom({"EwokText3": gdjs.Game_45Code.GDEwokText3Objects2});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Game_45Code.GDPlayerObjects1});
gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDEwokText3Objects1Objects = Hashtable.newFrom({"EwokText3": gdjs.Game_45Code.GDEwokText3Objects1});
gdjs.Game_45Code.eventsList27 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("StoryPoint"), gdjs.Game_45Code.GDStoryPointObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDStoryPointObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PlayerName"), gdjs.Game_45Code.GDPlayerNameObjects2);
gdjs.copyArray(runtimeScene.getObjects("Story1"), gdjs.Game_45Code.GDStory1Objects2);
gdjs.copyArray(runtimeScene.getObjects("TextBox"), gdjs.Game_45Code.GDTextBoxObjects2);
{for(var i = 0, len = gdjs.Game_45Code.GDTextBoxObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDTextBoxObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.Game_45Code.GDStory1Objects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDStory1Objects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.Game_45Code.GDPlayerNameObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDPlayerNameObjects2[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("StoryPoint"), gdjs.Game_45Code.GDStoryPointObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDStoryPointObjects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PlayerName"), gdjs.Game_45Code.GDPlayerNameObjects2);
gdjs.copyArray(runtimeScene.getObjects("Story1"), gdjs.Game_45Code.GDStory1Objects2);
gdjs.copyArray(runtimeScene.getObjects("TextBox"), gdjs.Game_45Code.GDTextBoxObjects2);
{for(var i = 0, len = gdjs.Game_45Code.GDTextBoxObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDTextBoxObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Game_45Code.GDStory1Objects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDStory1Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.Game_45Code.GDPlayerNameObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDPlayerNameObjects2[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("EwokText"), gdjs.Game_45Code.GDEwokTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDEwokTextObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("EwokName"), gdjs.Game_45Code.GDEwokNameObjects2);
gdjs.copyArray(runtimeScene.getObjects("StoryE1"), gdjs.Game_45Code.GDStoryE1Objects2);
gdjs.copyArray(runtimeScene.getObjects("TextBox2"), gdjs.Game_45Code.GDTextBox2Objects2);
{for(var i = 0, len = gdjs.Game_45Code.GDTextBox2Objects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDTextBox2Objects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.Game_45Code.GDEwokNameObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDEwokNameObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.Game_45Code.GDStoryE1Objects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDStoryE1Objects2[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("EwokText"), gdjs.Game_45Code.GDEwokTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDEwokTextObjects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("EwokName"), gdjs.Game_45Code.GDEwokNameObjects2);
gdjs.copyArray(runtimeScene.getObjects("StoryE1"), gdjs.Game_45Code.GDStoryE1Objects2);
gdjs.copyArray(runtimeScene.getObjects("TextBox2"), gdjs.Game_45Code.GDTextBox2Objects2);
{for(var i = 0, len = gdjs.Game_45Code.GDTextBox2Objects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDTextBox2Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.Game_45Code.GDEwokNameObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDEwokNameObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Game_45Code.GDStoryE1Objects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDStoryE1Objects2[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("EwokText2"), gdjs.Game_45Code.GDEwokText2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDEwokText2Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("EwokName2"), gdjs.Game_45Code.GDEwokName2Objects2);
gdjs.copyArray(runtimeScene.getObjects("HorcruxStory"), gdjs.Game_45Code.GDHorcruxStoryObjects2);
gdjs.copyArray(runtimeScene.getObjects("StoryE1h"), gdjs.Game_45Code.GDStoryE1hObjects2);
gdjs.copyArray(runtimeScene.getObjects("StoryE2"), gdjs.Game_45Code.GDStoryE2Objects2);
gdjs.copyArray(runtimeScene.getObjects("TextBox3"), gdjs.Game_45Code.GDTextBox3Objects2);
{for(var i = 0, len = gdjs.Game_45Code.GDTextBox3Objects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDTextBox3Objects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.Game_45Code.GDEwokName2Objects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDEwokName2Objects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.Game_45Code.GDStoryE2Objects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDStoryE2Objects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.Game_45Code.GDHorcruxStoryObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDHorcruxStoryObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.Game_45Code.GDStoryE1hObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDStoryE1hObjects2[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("EwokText2"), gdjs.Game_45Code.GDEwokText2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDEwokText2Objects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("EwokName2"), gdjs.Game_45Code.GDEwokName2Objects2);
gdjs.copyArray(runtimeScene.getObjects("HorcruxStory"), gdjs.Game_45Code.GDHorcruxStoryObjects2);
gdjs.copyArray(runtimeScene.getObjects("StoryE1h"), gdjs.Game_45Code.GDStoryE1hObjects2);
gdjs.copyArray(runtimeScene.getObjects("StoryE2"), gdjs.Game_45Code.GDStoryE2Objects2);
gdjs.copyArray(runtimeScene.getObjects("TextBox3"), gdjs.Game_45Code.GDTextBox3Objects2);
{for(var i = 0, len = gdjs.Game_45Code.GDTextBox3Objects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDTextBox3Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.Game_45Code.GDEwokName2Objects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDEwokName2Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.Game_45Code.GDStoryE2Objects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDStoryE2Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.Game_45Code.GDHorcruxStoryObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDHorcruxStoryObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Game_45Code.GDStoryE1hObjects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDStoryE1hObjects2[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("EwokText3"), gdjs.Game_45Code.GDEwokText3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects2Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDEwokText3Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("EwokName3"), gdjs.Game_45Code.GDEwokName3Objects2);
gdjs.copyArray(runtimeScene.getObjects("StoryE3"), gdjs.Game_45Code.GDStoryE3Objects2);
gdjs.copyArray(runtimeScene.getObjects("TextBox4"), gdjs.Game_45Code.GDTextBox4Objects2);
{for(var i = 0, len = gdjs.Game_45Code.GDTextBox4Objects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDTextBox4Objects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.Game_45Code.GDEwokName3Objects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDEwokName3Objects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.Game_45Code.GDStoryE3Objects2.length ;i < len;++i) {
    gdjs.Game_45Code.GDStoryE3Objects2[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("EwokText3"), gdjs.Game_45Code.GDEwokText3Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_45Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDPlayerObjects1Objects, gdjs.Game_45Code.mapOfGDgdjs_9546Game_959545Code_9546GDEwokText3Objects1Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("EwokName3"), gdjs.Game_45Code.GDEwokName3Objects1);
gdjs.copyArray(runtimeScene.getObjects("StoryE3"), gdjs.Game_45Code.GDStoryE3Objects1);
gdjs.copyArray(runtimeScene.getObjects("TextBox4"), gdjs.Game_45Code.GDTextBox4Objects1);
{for(var i = 0, len = gdjs.Game_45Code.GDTextBox4Objects1.length ;i < len;++i) {
    gdjs.Game_45Code.GDTextBox4Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.Game_45Code.GDEwokName3Objects1.length ;i < len;++i) {
    gdjs.Game_45Code.GDEwokName3Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.Game_45Code.GDStoryE3Objects1.length ;i < len;++i) {
    gdjs.Game_45Code.GDStoryE3Objects1[i].hide();
}
}}

}


};gdjs.Game_45Code.eventsList28 = function(runtimeScene) {

{


gdjs.Game_45Code.eventsList0(runtimeScene);
}


{


gdjs.Game_45Code.eventsList4(runtimeScene);
}


{


gdjs.Game_45Code.eventsList5(runtimeScene);
}


{


gdjs.Game_45Code.eventsList6(runtimeScene);
}


{


gdjs.Game_45Code.eventsList7(runtimeScene);
}


{


gdjs.Game_45Code.eventsList15(runtimeScene);
}


{


gdjs.Game_45Code.eventsList19(runtimeScene);
}


{


gdjs.Game_45Code.eventsList20(runtimeScene);
}


{


gdjs.Game_45Code.eventsList26(runtimeScene);
}


{


gdjs.Game_45Code.eventsList27(runtimeScene);
}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.Game_45Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Game_45Code.GDPlayerObjects1.length = 0;
gdjs.Game_45Code.GDPlayerObjects2.length = 0;
gdjs.Game_45Code.GDPlayerObjects3.length = 0;
gdjs.Game_45Code.GDPlayerObjects4.length = 0;
gdjs.Game_45Code.GDPlayerObjects5.length = 0;
gdjs.Game_45Code.GDNewObjectObjects1.length = 0;
gdjs.Game_45Code.GDNewObjectObjects2.length = 0;
gdjs.Game_45Code.GDNewObjectObjects3.length = 0;
gdjs.Game_45Code.GDNewObjectObjects4.length = 0;
gdjs.Game_45Code.GDNewObjectObjects5.length = 0;
gdjs.Game_45Code.GDGroundLObjects1.length = 0;
gdjs.Game_45Code.GDGroundLObjects2.length = 0;
gdjs.Game_45Code.GDGroundLObjects3.length = 0;
gdjs.Game_45Code.GDGroundLObjects4.length = 0;
gdjs.Game_45Code.GDGroundLObjects5.length = 0;
gdjs.Game_45Code.GDGroundRObjects1.length = 0;
gdjs.Game_45Code.GDGroundRObjects2.length = 0;
gdjs.Game_45Code.GDGroundRObjects3.length = 0;
gdjs.Game_45Code.GDGroundRObjects4.length = 0;
gdjs.Game_45Code.GDGroundRObjects5.length = 0;
gdjs.Game_45Code.GDGroundM1Objects1.length = 0;
gdjs.Game_45Code.GDGroundM1Objects2.length = 0;
gdjs.Game_45Code.GDGroundM1Objects3.length = 0;
gdjs.Game_45Code.GDGroundM1Objects4.length = 0;
gdjs.Game_45Code.GDGroundM1Objects5.length = 0;
gdjs.Game_45Code.GDGroundM2Objects1.length = 0;
gdjs.Game_45Code.GDGroundM2Objects2.length = 0;
gdjs.Game_45Code.GDGroundM2Objects3.length = 0;
gdjs.Game_45Code.GDGroundM2Objects4.length = 0;
gdjs.Game_45Code.GDGroundM2Objects5.length = 0;
gdjs.Game_45Code.GDGroundM3Objects1.length = 0;
gdjs.Game_45Code.GDGroundM3Objects2.length = 0;
gdjs.Game_45Code.GDGroundM3Objects3.length = 0;
gdjs.Game_45Code.GDGroundM3Objects4.length = 0;
gdjs.Game_45Code.GDGroundM3Objects5.length = 0;
gdjs.Game_45Code.GDGroundM4Objects1.length = 0;
gdjs.Game_45Code.GDGroundM4Objects2.length = 0;
gdjs.Game_45Code.GDGroundM4Objects3.length = 0;
gdjs.Game_45Code.GDGroundM4Objects4.length = 0;
gdjs.Game_45Code.GDGroundM4Objects5.length = 0;
gdjs.Game_45Code.GDGroundMr1Objects1.length = 0;
gdjs.Game_45Code.GDGroundMr1Objects2.length = 0;
gdjs.Game_45Code.GDGroundMr1Objects3.length = 0;
gdjs.Game_45Code.GDGroundMr1Objects4.length = 0;
gdjs.Game_45Code.GDGroundMr1Objects5.length = 0;
gdjs.Game_45Code.GDGroundMr2Objects1.length = 0;
gdjs.Game_45Code.GDGroundMr2Objects2.length = 0;
gdjs.Game_45Code.GDGroundMr2Objects3.length = 0;
gdjs.Game_45Code.GDGroundMr2Objects4.length = 0;
gdjs.Game_45Code.GDGroundMr2Objects5.length = 0;
gdjs.Game_45Code.GDGroundMr3Objects1.length = 0;
gdjs.Game_45Code.GDGroundMr3Objects2.length = 0;
gdjs.Game_45Code.GDGroundMr3Objects3.length = 0;
gdjs.Game_45Code.GDGroundMr3Objects4.length = 0;
gdjs.Game_45Code.GDGroundMr3Objects5.length = 0;
gdjs.Game_45Code.GDGroundMu1Objects1.length = 0;
gdjs.Game_45Code.GDGroundMu1Objects2.length = 0;
gdjs.Game_45Code.GDGroundMu1Objects3.length = 0;
gdjs.Game_45Code.GDGroundMu1Objects4.length = 0;
gdjs.Game_45Code.GDGroundMu1Objects5.length = 0;
gdjs.Game_45Code.GDGroundMu2Objects1.length = 0;
gdjs.Game_45Code.GDGroundMu2Objects2.length = 0;
gdjs.Game_45Code.GDGroundMu2Objects3.length = 0;
gdjs.Game_45Code.GDGroundMu2Objects4.length = 0;
gdjs.Game_45Code.GDGroundMu2Objects5.length = 0;
gdjs.Game_45Code.GDGroundMu3Objects1.length = 0;
gdjs.Game_45Code.GDGroundMu3Objects2.length = 0;
gdjs.Game_45Code.GDGroundMu3Objects3.length = 0;
gdjs.Game_45Code.GDGroundMu3Objects4.length = 0;
gdjs.Game_45Code.GDGroundMu3Objects5.length = 0;
gdjs.Game_45Code.GDFloatG1Objects1.length = 0;
gdjs.Game_45Code.GDFloatG1Objects2.length = 0;
gdjs.Game_45Code.GDFloatG1Objects3.length = 0;
gdjs.Game_45Code.GDFloatG1Objects4.length = 0;
gdjs.Game_45Code.GDFloatG1Objects5.length = 0;
gdjs.Game_45Code.GDFloatG2Objects1.length = 0;
gdjs.Game_45Code.GDFloatG2Objects2.length = 0;
gdjs.Game_45Code.GDFloatG2Objects3.length = 0;
gdjs.Game_45Code.GDFloatG2Objects4.length = 0;
gdjs.Game_45Code.GDFloatG2Objects5.length = 0;
gdjs.Game_45Code.GDFloatR1Objects1.length = 0;
gdjs.Game_45Code.GDFloatR1Objects2.length = 0;
gdjs.Game_45Code.GDFloatR1Objects3.length = 0;
gdjs.Game_45Code.GDFloatR1Objects4.length = 0;
gdjs.Game_45Code.GDFloatR1Objects5.length = 0;
gdjs.Game_45Code.GDFloatR2Objects1.length = 0;
gdjs.Game_45Code.GDFloatR2Objects2.length = 0;
gdjs.Game_45Code.GDFloatR2Objects3.length = 0;
gdjs.Game_45Code.GDFloatR2Objects4.length = 0;
gdjs.Game_45Code.GDFloatR2Objects5.length = 0;
gdjs.Game_45Code.GDMovFloatR3Objects1.length = 0;
gdjs.Game_45Code.GDMovFloatR3Objects2.length = 0;
gdjs.Game_45Code.GDMovFloatR3Objects3.length = 0;
gdjs.Game_45Code.GDMovFloatR3Objects4.length = 0;
gdjs.Game_45Code.GDMovFloatR3Objects5.length = 0;
gdjs.Game_45Code.GDMovFloatR2Objects1.length = 0;
gdjs.Game_45Code.GDMovFloatR2Objects2.length = 0;
gdjs.Game_45Code.GDMovFloatR2Objects3.length = 0;
gdjs.Game_45Code.GDMovFloatR2Objects4.length = 0;
gdjs.Game_45Code.GDMovFloatR2Objects5.length = 0;
gdjs.Game_45Code.GDBridgeLObjects1.length = 0;
gdjs.Game_45Code.GDBridgeLObjects2.length = 0;
gdjs.Game_45Code.GDBridgeLObjects3.length = 0;
gdjs.Game_45Code.GDBridgeLObjects4.length = 0;
gdjs.Game_45Code.GDBridgeLObjects5.length = 0;
gdjs.Game_45Code.GDBridgeMObjects1.length = 0;
gdjs.Game_45Code.GDBridgeMObjects2.length = 0;
gdjs.Game_45Code.GDBridgeMObjects3.length = 0;
gdjs.Game_45Code.GDBridgeMObjects4.length = 0;
gdjs.Game_45Code.GDBridgeMObjects5.length = 0;
gdjs.Game_45Code.GDBridgeRObjects1.length = 0;
gdjs.Game_45Code.GDBridgeRObjects2.length = 0;
gdjs.Game_45Code.GDBridgeRObjects3.length = 0;
gdjs.Game_45Code.GDBridgeRObjects4.length = 0;
gdjs.Game_45Code.GDBridgeRObjects5.length = 0;
gdjs.Game_45Code.GDCoinUiObjects1.length = 0;
gdjs.Game_45Code.GDCoinUiObjects2.length = 0;
gdjs.Game_45Code.GDCoinUiObjects3.length = 0;
gdjs.Game_45Code.GDCoinUiObjects4.length = 0;
gdjs.Game_45Code.GDCoinUiObjects5.length = 0;
gdjs.Game_45Code.GDCoinObjects1.length = 0;
gdjs.Game_45Code.GDCoinObjects2.length = 0;
gdjs.Game_45Code.GDCoinObjects3.length = 0;
gdjs.Game_45Code.GDCoinObjects4.length = 0;
gdjs.Game_45Code.GDCoinObjects5.length = 0;
gdjs.Game_45Code.GDScoreDiamondObjects1.length = 0;
gdjs.Game_45Code.GDScoreDiamondObjects2.length = 0;
gdjs.Game_45Code.GDScoreDiamondObjects3.length = 0;
gdjs.Game_45Code.GDScoreDiamondObjects4.length = 0;
gdjs.Game_45Code.GDScoreDiamondObjects5.length = 0;
gdjs.Game_45Code.GDScoreObjects1.length = 0;
gdjs.Game_45Code.GDScoreObjects2.length = 0;
gdjs.Game_45Code.GDScoreObjects3.length = 0;
gdjs.Game_45Code.GDScoreObjects4.length = 0;
gdjs.Game_45Code.GDScoreObjects5.length = 0;
gdjs.Game_45Code.GDOpstaclePatchObjects1.length = 0;
gdjs.Game_45Code.GDOpstaclePatchObjects2.length = 0;
gdjs.Game_45Code.GDOpstaclePatchObjects3.length = 0;
gdjs.Game_45Code.GDOpstaclePatchObjects4.length = 0;
gdjs.Game_45Code.GDOpstaclePatchObjects5.length = 0;
gdjs.Game_45Code.GDPortalObjects1.length = 0;
gdjs.Game_45Code.GDPortalObjects2.length = 0;
gdjs.Game_45Code.GDPortalObjects3.length = 0;
gdjs.Game_45Code.GDPortalObjects4.length = 0;
gdjs.Game_45Code.GDPortalObjects5.length = 0;
gdjs.Game_45Code.GDPortal2Objects1.length = 0;
gdjs.Game_45Code.GDPortal2Objects2.length = 0;
gdjs.Game_45Code.GDPortal2Objects3.length = 0;
gdjs.Game_45Code.GDPortal2Objects4.length = 0;
gdjs.Game_45Code.GDPortal2Objects5.length = 0;
gdjs.Game_45Code.GDPortalaObjects1.length = 0;
gdjs.Game_45Code.GDPortalaObjects2.length = 0;
gdjs.Game_45Code.GDPortalaObjects3.length = 0;
gdjs.Game_45Code.GDPortalaObjects4.length = 0;
gdjs.Game_45Code.GDPortalaObjects5.length = 0;
gdjs.Game_45Code.GDPortala2Objects1.length = 0;
gdjs.Game_45Code.GDPortala2Objects2.length = 0;
gdjs.Game_45Code.GDPortala2Objects3.length = 0;
gdjs.Game_45Code.GDPortala2Objects4.length = 0;
gdjs.Game_45Code.GDPortala2Objects5.length = 0;
gdjs.Game_45Code.GDPortalcObjects1.length = 0;
gdjs.Game_45Code.GDPortalcObjects2.length = 0;
gdjs.Game_45Code.GDPortalcObjects3.length = 0;
gdjs.Game_45Code.GDPortalcObjects4.length = 0;
gdjs.Game_45Code.GDPortalcObjects5.length = 0;
gdjs.Game_45Code.GDPortalc2Objects1.length = 0;
gdjs.Game_45Code.GDPortalc2Objects2.length = 0;
gdjs.Game_45Code.GDPortalc2Objects3.length = 0;
gdjs.Game_45Code.GDPortalc2Objects4.length = 0;
gdjs.Game_45Code.GDPortalc2Objects5.length = 0;
gdjs.Game_45Code.GDTreeBgObjects1.length = 0;
gdjs.Game_45Code.GDTreeBgObjects2.length = 0;
gdjs.Game_45Code.GDTreeBgObjects3.length = 0;
gdjs.Game_45Code.GDTreeBgObjects4.length = 0;
gdjs.Game_45Code.GDTreeBgObjects5.length = 0;
gdjs.Game_45Code.GDDiamondObjects1.length = 0;
gdjs.Game_45Code.GDDiamondObjects2.length = 0;
gdjs.Game_45Code.GDDiamondObjects3.length = 0;
gdjs.Game_45Code.GDDiamondObjects4.length = 0;
gdjs.Game_45Code.GDDiamondObjects5.length = 0;
gdjs.Game_45Code.GDRockBgObjects1.length = 0;
gdjs.Game_45Code.GDRockBgObjects2.length = 0;
gdjs.Game_45Code.GDRockBgObjects3.length = 0;
gdjs.Game_45Code.GDRockBgObjects4.length = 0;
gdjs.Game_45Code.GDRockBgObjects5.length = 0;
gdjs.Game_45Code.GDFireCkObjects1.length = 0;
gdjs.Game_45Code.GDFireCkObjects2.length = 0;
gdjs.Game_45Code.GDFireCkObjects3.length = 0;
gdjs.Game_45Code.GDFireCkObjects4.length = 0;
gdjs.Game_45Code.GDFireCkObjects5.length = 0;
gdjs.Game_45Code.GDCheckpointObjects1.length = 0;
gdjs.Game_45Code.GDCheckpointObjects2.length = 0;
gdjs.Game_45Code.GDCheckpointObjects3.length = 0;
gdjs.Game_45Code.GDCheckpointObjects4.length = 0;
gdjs.Game_45Code.GDCheckpointObjects5.length = 0;
gdjs.Game_45Code.GDHorcruxStoryObjects1.length = 0;
gdjs.Game_45Code.GDHorcruxStoryObjects2.length = 0;
gdjs.Game_45Code.GDHorcruxStoryObjects3.length = 0;
gdjs.Game_45Code.GDHorcruxStoryObjects4.length = 0;
gdjs.Game_45Code.GDHorcruxStoryObjects5.length = 0;
gdjs.Game_45Code.GDHorcrux1Objects1.length = 0;
gdjs.Game_45Code.GDHorcrux1Objects2.length = 0;
gdjs.Game_45Code.GDHorcrux1Objects3.length = 0;
gdjs.Game_45Code.GDHorcrux1Objects4.length = 0;
gdjs.Game_45Code.GDHorcrux1Objects5.length = 0;
gdjs.Game_45Code.GDDeadZoneObjects1.length = 0;
gdjs.Game_45Code.GDDeadZoneObjects2.length = 0;
gdjs.Game_45Code.GDDeadZoneObjects3.length = 0;
gdjs.Game_45Code.GDDeadZoneObjects4.length = 0;
gdjs.Game_45Code.GDDeadZoneObjects5.length = 0;
gdjs.Game_45Code.GDFloatLObjects1.length = 0;
gdjs.Game_45Code.GDFloatLObjects2.length = 0;
gdjs.Game_45Code.GDFloatLObjects3.length = 0;
gdjs.Game_45Code.GDFloatLObjects4.length = 0;
gdjs.Game_45Code.GDFloatLObjects5.length = 0;
gdjs.Game_45Code.GDFloatMObjects1.length = 0;
gdjs.Game_45Code.GDFloatMObjects2.length = 0;
gdjs.Game_45Code.GDFloatMObjects3.length = 0;
gdjs.Game_45Code.GDFloatMObjects4.length = 0;
gdjs.Game_45Code.GDFloatMObjects5.length = 0;
gdjs.Game_45Code.GDFloatRObjects1.length = 0;
gdjs.Game_45Code.GDFloatRObjects2.length = 0;
gdjs.Game_45Code.GDFloatRObjects3.length = 0;
gdjs.Game_45Code.GDFloatRObjects4.length = 0;
gdjs.Game_45Code.GDFloatRObjects5.length = 0;
gdjs.Game_45Code.GDPlayerHbObjects1.length = 0;
gdjs.Game_45Code.GDPlayerHbObjects2.length = 0;
gdjs.Game_45Code.GDPlayerHbObjects3.length = 0;
gdjs.Game_45Code.GDPlayerHbObjects4.length = 0;
gdjs.Game_45Code.GDPlayerHbObjects5.length = 0;
gdjs.Game_45Code.GDSaveHbObjects1.length = 0;
gdjs.Game_45Code.GDSaveHbObjects2.length = 0;
gdjs.Game_45Code.GDSaveHbObjects3.length = 0;
gdjs.Game_45Code.GDSaveHbObjects4.length = 0;
gdjs.Game_45Code.GDSaveHbObjects5.length = 0;
gdjs.Game_45Code.GDEnmObjects1.length = 0;
gdjs.Game_45Code.GDEnmObjects2.length = 0;
gdjs.Game_45Code.GDEnmObjects3.length = 0;
gdjs.Game_45Code.GDEnmObjects4.length = 0;
gdjs.Game_45Code.GDEnmObjects5.length = 0;
gdjs.Game_45Code.GDNpcEwokObjects1.length = 0;
gdjs.Game_45Code.GDNpcEwokObjects2.length = 0;
gdjs.Game_45Code.GDNpcEwokObjects3.length = 0;
gdjs.Game_45Code.GDNpcEwokObjects4.length = 0;
gdjs.Game_45Code.GDNpcEwokObjects5.length = 0;
gdjs.Game_45Code.GDBackgroundObjects1.length = 0;
gdjs.Game_45Code.GDBackgroundObjects2.length = 0;
gdjs.Game_45Code.GDBackgroundObjects3.length = 0;
gdjs.Game_45Code.GDBackgroundObjects4.length = 0;
gdjs.Game_45Code.GDBackgroundObjects5.length = 0;
gdjs.Game_45Code.GDHealth2Objects1.length = 0;
gdjs.Game_45Code.GDHealth2Objects2.length = 0;
gdjs.Game_45Code.GDHealth2Objects3.length = 0;
gdjs.Game_45Code.GDHealth2Objects4.length = 0;
gdjs.Game_45Code.GDHealth2Objects5.length = 0;
gdjs.Game_45Code.GDHealth3Objects1.length = 0;
gdjs.Game_45Code.GDHealth3Objects2.length = 0;
gdjs.Game_45Code.GDHealth3Objects3.length = 0;
gdjs.Game_45Code.GDHealth3Objects4.length = 0;
gdjs.Game_45Code.GDHealth3Objects5.length = 0;
gdjs.Game_45Code.GDHealthObjects1.length = 0;
gdjs.Game_45Code.GDHealthObjects2.length = 0;
gdjs.Game_45Code.GDHealthObjects3.length = 0;
gdjs.Game_45Code.GDHealthObjects4.length = 0;
gdjs.Game_45Code.GDHealthObjects5.length = 0;
gdjs.Game_45Code.GDUpObjects1.length = 0;
gdjs.Game_45Code.GDUpObjects2.length = 0;
gdjs.Game_45Code.GDUpObjects3.length = 0;
gdjs.Game_45Code.GDUpObjects4.length = 0;
gdjs.Game_45Code.GDUpObjects5.length = 0;
gdjs.Game_45Code.GDDownObjects1.length = 0;
gdjs.Game_45Code.GDDownObjects2.length = 0;
gdjs.Game_45Code.GDDownObjects3.length = 0;
gdjs.Game_45Code.GDDownObjects4.length = 0;
gdjs.Game_45Code.GDDownObjects5.length = 0;
gdjs.Game_45Code.GDLavaObjects1.length = 0;
gdjs.Game_45Code.GDLavaObjects2.length = 0;
gdjs.Game_45Code.GDLavaObjects3.length = 0;
gdjs.Game_45Code.GDLavaObjects4.length = 0;
gdjs.Game_45Code.GDLavaObjects5.length = 0;
gdjs.Game_45Code.GDSpikeObjects1.length = 0;
gdjs.Game_45Code.GDSpikeObjects2.length = 0;
gdjs.Game_45Code.GDSpikeObjects3.length = 0;
gdjs.Game_45Code.GDSpikeObjects4.length = 0;
gdjs.Game_45Code.GDSpikeObjects5.length = 0;
gdjs.Game_45Code.GDBgMidObjects1.length = 0;
gdjs.Game_45Code.GDBgMidObjects2.length = 0;
gdjs.Game_45Code.GDBgMidObjects3.length = 0;
gdjs.Game_45Code.GDBgMidObjects4.length = 0;
gdjs.Game_45Code.GDBgMidObjects5.length = 0;
gdjs.Game_45Code.GDBgUpRObjects1.length = 0;
gdjs.Game_45Code.GDBgUpRObjects2.length = 0;
gdjs.Game_45Code.GDBgUpRObjects3.length = 0;
gdjs.Game_45Code.GDBgUpRObjects4.length = 0;
gdjs.Game_45Code.GDBgUpRObjects5.length = 0;
gdjs.Game_45Code.GDBgLObjects1.length = 0;
gdjs.Game_45Code.GDBgLObjects2.length = 0;
gdjs.Game_45Code.GDBgLObjects3.length = 0;
gdjs.Game_45Code.GDBgLObjects4.length = 0;
gdjs.Game_45Code.GDBgLObjects5.length = 0;
gdjs.Game_45Code.GDBgRObjects1.length = 0;
gdjs.Game_45Code.GDBgRObjects2.length = 0;
gdjs.Game_45Code.GDBgRObjects3.length = 0;
gdjs.Game_45Code.GDBgRObjects4.length = 0;
gdjs.Game_45Code.GDBgRObjects5.length = 0;
gdjs.Game_45Code.GDBgLoLObjects1.length = 0;
gdjs.Game_45Code.GDBgLoLObjects2.length = 0;
gdjs.Game_45Code.GDBgLoLObjects3.length = 0;
gdjs.Game_45Code.GDBgLoLObjects4.length = 0;
gdjs.Game_45Code.GDBgLoLObjects5.length = 0;
gdjs.Game_45Code.GDBgLoRObjects1.length = 0;
gdjs.Game_45Code.GDBgLoRObjects2.length = 0;
gdjs.Game_45Code.GDBgLoRObjects3.length = 0;
gdjs.Game_45Code.GDBgLoRObjects4.length = 0;
gdjs.Game_45Code.GDBgLoRObjects5.length = 0;
gdjs.Game_45Code.GDBgUpLObjects1.length = 0;
gdjs.Game_45Code.GDBgUpLObjects2.length = 0;
gdjs.Game_45Code.GDBgUpLObjects3.length = 0;
gdjs.Game_45Code.GDBgUpLObjects4.length = 0;
gdjs.Game_45Code.GDBgUpLObjects5.length = 0;
gdjs.Game_45Code.GDCelengObjects1.length = 0;
gdjs.Game_45Code.GDCelengObjects2.length = 0;
gdjs.Game_45Code.GDCelengObjects3.length = 0;
gdjs.Game_45Code.GDCelengObjects4.length = 0;
gdjs.Game_45Code.GDCelengObjects5.length = 0;
gdjs.Game_45Code.GDCeleng2Objects1.length = 0;
gdjs.Game_45Code.GDCeleng2Objects2.length = 0;
gdjs.Game_45Code.GDCeleng2Objects3.length = 0;
gdjs.Game_45Code.GDCeleng2Objects4.length = 0;
gdjs.Game_45Code.GDCeleng2Objects5.length = 0;
gdjs.Game_45Code.GDPapanObjects1.length = 0;
gdjs.Game_45Code.GDPapanObjects2.length = 0;
gdjs.Game_45Code.GDPapanObjects3.length = 0;
gdjs.Game_45Code.GDPapanObjects4.length = 0;
gdjs.Game_45Code.GDPapanObjects5.length = 0;
gdjs.Game_45Code.GDBarrelObjects1.length = 0;
gdjs.Game_45Code.GDBarrelObjects2.length = 0;
gdjs.Game_45Code.GDBarrelObjects3.length = 0;
gdjs.Game_45Code.GDBarrelObjects4.length = 0;
gdjs.Game_45Code.GDBarrelObjects5.length = 0;
gdjs.Game_45Code.GDSaw2Objects1.length = 0;
gdjs.Game_45Code.GDSaw2Objects2.length = 0;
gdjs.Game_45Code.GDSaw2Objects3.length = 0;
gdjs.Game_45Code.GDSaw2Objects4.length = 0;
gdjs.Game_45Code.GDSaw2Objects5.length = 0;
gdjs.Game_45Code.GDSawObjects1.length = 0;
gdjs.Game_45Code.GDSawObjects2.length = 0;
gdjs.Game_45Code.GDSawObjects3.length = 0;
gdjs.Game_45Code.GDSawObjects4.length = 0;
gdjs.Game_45Code.GDSawObjects5.length = 0;
gdjs.Game_45Code.GDRightGur2Objects1.length = 0;
gdjs.Game_45Code.GDRightGur2Objects2.length = 0;
gdjs.Game_45Code.GDRightGur2Objects3.length = 0;
gdjs.Game_45Code.GDRightGur2Objects4.length = 0;
gdjs.Game_45Code.GDRightGur2Objects5.length = 0;
gdjs.Game_45Code.GDRightGurObjects1.length = 0;
gdjs.Game_45Code.GDRightGurObjects2.length = 0;
gdjs.Game_45Code.GDRightGurObjects3.length = 0;
gdjs.Game_45Code.GDRightGurObjects4.length = 0;
gdjs.Game_45Code.GDRightGurObjects5.length = 0;
gdjs.Game_45Code.GDRightObjects1.length = 0;
gdjs.Game_45Code.GDRightObjects2.length = 0;
gdjs.Game_45Code.GDRightObjects3.length = 0;
gdjs.Game_45Code.GDRightObjects4.length = 0;
gdjs.Game_45Code.GDRightObjects5.length = 0;
gdjs.Game_45Code.GDLeftGur2Objects1.length = 0;
gdjs.Game_45Code.GDLeftGur2Objects2.length = 0;
gdjs.Game_45Code.GDLeftGur2Objects3.length = 0;
gdjs.Game_45Code.GDLeftGur2Objects4.length = 0;
gdjs.Game_45Code.GDLeftGur2Objects5.length = 0;
gdjs.Game_45Code.GDLeftGurObjects1.length = 0;
gdjs.Game_45Code.GDLeftGurObjects2.length = 0;
gdjs.Game_45Code.GDLeftGurObjects3.length = 0;
gdjs.Game_45Code.GDLeftGurObjects4.length = 0;
gdjs.Game_45Code.GDLeftGurObjects5.length = 0;
gdjs.Game_45Code.GDLeftObjects1.length = 0;
gdjs.Game_45Code.GDLeftObjects2.length = 0;
gdjs.Game_45Code.GDLeftObjects3.length = 0;
gdjs.Game_45Code.GDLeftObjects4.length = 0;
gdjs.Game_45Code.GDLeftObjects5.length = 0;
gdjs.Game_45Code.GDFlame2Objects1.length = 0;
gdjs.Game_45Code.GDFlame2Objects2.length = 0;
gdjs.Game_45Code.GDFlame2Objects3.length = 0;
gdjs.Game_45Code.GDFlame2Objects4.length = 0;
gdjs.Game_45Code.GDFlame2Objects5.length = 0;
gdjs.Game_45Code.GDFlame3Objects1.length = 0;
gdjs.Game_45Code.GDFlame3Objects2.length = 0;
gdjs.Game_45Code.GDFlame3Objects3.length = 0;
gdjs.Game_45Code.GDFlame3Objects4.length = 0;
gdjs.Game_45Code.GDFlame3Objects5.length = 0;
gdjs.Game_45Code.GDFlameObjects1.length = 0;
gdjs.Game_45Code.GDFlameObjects2.length = 0;
gdjs.Game_45Code.GDFlameObjects3.length = 0;
gdjs.Game_45Code.GDFlameObjects4.length = 0;
gdjs.Game_45Code.GDFlameObjects5.length = 0;
gdjs.Game_45Code.GDFlameHb2Objects1.length = 0;
gdjs.Game_45Code.GDFlameHb2Objects2.length = 0;
gdjs.Game_45Code.GDFlameHb2Objects3.length = 0;
gdjs.Game_45Code.GDFlameHb2Objects4.length = 0;
gdjs.Game_45Code.GDFlameHb2Objects5.length = 0;
gdjs.Game_45Code.GDFlameHb3Objects1.length = 0;
gdjs.Game_45Code.GDFlameHb3Objects2.length = 0;
gdjs.Game_45Code.GDFlameHb3Objects3.length = 0;
gdjs.Game_45Code.GDFlameHb3Objects4.length = 0;
gdjs.Game_45Code.GDFlameHb3Objects5.length = 0;
gdjs.Game_45Code.GDFlameHbObjects1.length = 0;
gdjs.Game_45Code.GDFlameHbObjects2.length = 0;
gdjs.Game_45Code.GDFlameHbObjects3.length = 0;
gdjs.Game_45Code.GDFlameHbObjects4.length = 0;
gdjs.Game_45Code.GDFlameHbObjects5.length = 0;
gdjs.Game_45Code.GDGuardian2Objects1.length = 0;
gdjs.Game_45Code.GDGuardian2Objects2.length = 0;
gdjs.Game_45Code.GDGuardian2Objects3.length = 0;
gdjs.Game_45Code.GDGuardian2Objects4.length = 0;
gdjs.Game_45Code.GDGuardian2Objects5.length = 0;
gdjs.Game_45Code.GDGuardianObjects1.length = 0;
gdjs.Game_45Code.GDGuardianObjects2.length = 0;
gdjs.Game_45Code.GDGuardianObjects3.length = 0;
gdjs.Game_45Code.GDGuardianObjects4.length = 0;
gdjs.Game_45Code.GDGuardianObjects5.length = 0;
gdjs.Game_45Code.GDTextBox2Objects1.length = 0;
gdjs.Game_45Code.GDTextBox2Objects2.length = 0;
gdjs.Game_45Code.GDTextBox2Objects3.length = 0;
gdjs.Game_45Code.GDTextBox2Objects4.length = 0;
gdjs.Game_45Code.GDTextBox2Objects5.length = 0;
gdjs.Game_45Code.GDTextBox3Objects1.length = 0;
gdjs.Game_45Code.GDTextBox3Objects2.length = 0;
gdjs.Game_45Code.GDTextBox3Objects3.length = 0;
gdjs.Game_45Code.GDTextBox3Objects4.length = 0;
gdjs.Game_45Code.GDTextBox3Objects5.length = 0;
gdjs.Game_45Code.GDTextBox4Objects1.length = 0;
gdjs.Game_45Code.GDTextBox4Objects2.length = 0;
gdjs.Game_45Code.GDTextBox4Objects3.length = 0;
gdjs.Game_45Code.GDTextBox4Objects4.length = 0;
gdjs.Game_45Code.GDTextBox4Objects5.length = 0;
gdjs.Game_45Code.GDTextBoxObjects1.length = 0;
gdjs.Game_45Code.GDTextBoxObjects2.length = 0;
gdjs.Game_45Code.GDTextBoxObjects3.length = 0;
gdjs.Game_45Code.GDTextBoxObjects4.length = 0;
gdjs.Game_45Code.GDTextBoxObjects5.length = 0;
gdjs.Game_45Code.GDStoryPoint2Objects1.length = 0;
gdjs.Game_45Code.GDStoryPoint2Objects2.length = 0;
gdjs.Game_45Code.GDStoryPoint2Objects3.length = 0;
gdjs.Game_45Code.GDStoryPoint2Objects4.length = 0;
gdjs.Game_45Code.GDStoryPoint2Objects5.length = 0;
gdjs.Game_45Code.GDStoryPointObjects1.length = 0;
gdjs.Game_45Code.GDStoryPointObjects2.length = 0;
gdjs.Game_45Code.GDStoryPointObjects3.length = 0;
gdjs.Game_45Code.GDStoryPointObjects4.length = 0;
gdjs.Game_45Code.GDStoryPointObjects5.length = 0;
gdjs.Game_45Code.GDGuardianSensorL2Objects1.length = 0;
gdjs.Game_45Code.GDGuardianSensorL2Objects2.length = 0;
gdjs.Game_45Code.GDGuardianSensorL2Objects3.length = 0;
gdjs.Game_45Code.GDGuardianSensorL2Objects4.length = 0;
gdjs.Game_45Code.GDGuardianSensorL2Objects5.length = 0;
gdjs.Game_45Code.GDGuardianSensorLObjects1.length = 0;
gdjs.Game_45Code.GDGuardianSensorLObjects2.length = 0;
gdjs.Game_45Code.GDGuardianSensorLObjects3.length = 0;
gdjs.Game_45Code.GDGuardianSensorLObjects4.length = 0;
gdjs.Game_45Code.GDGuardianSensorLObjects5.length = 0;
gdjs.Game_45Code.GDGuardianSensorR2Objects1.length = 0;
gdjs.Game_45Code.GDGuardianSensorR2Objects2.length = 0;
gdjs.Game_45Code.GDGuardianSensorR2Objects3.length = 0;
gdjs.Game_45Code.GDGuardianSensorR2Objects4.length = 0;
gdjs.Game_45Code.GDGuardianSensorR2Objects5.length = 0;
gdjs.Game_45Code.GDGuardianSensorRObjects1.length = 0;
gdjs.Game_45Code.GDGuardianSensorRObjects2.length = 0;
gdjs.Game_45Code.GDGuardianSensorRObjects3.length = 0;
gdjs.Game_45Code.GDGuardianSensorRObjects4.length = 0;
gdjs.Game_45Code.GDGuardianSensorRObjects5.length = 0;
gdjs.Game_45Code.GDStoryE2Objects1.length = 0;
gdjs.Game_45Code.GDStoryE2Objects2.length = 0;
gdjs.Game_45Code.GDStoryE2Objects3.length = 0;
gdjs.Game_45Code.GDStoryE2Objects4.length = 0;
gdjs.Game_45Code.GDStoryE2Objects5.length = 0;
gdjs.Game_45Code.GDStoryE3Objects1.length = 0;
gdjs.Game_45Code.GDStoryE3Objects2.length = 0;
gdjs.Game_45Code.GDStoryE3Objects3.length = 0;
gdjs.Game_45Code.GDStoryE3Objects4.length = 0;
gdjs.Game_45Code.GDStoryE3Objects5.length = 0;
gdjs.Game_45Code.GDStoryE1Objects1.length = 0;
gdjs.Game_45Code.GDStoryE1Objects2.length = 0;
gdjs.Game_45Code.GDStoryE1Objects3.length = 0;
gdjs.Game_45Code.GDStoryE1Objects4.length = 0;
gdjs.Game_45Code.GDStoryE1Objects5.length = 0;
gdjs.Game_45Code.GDStory1Objects1.length = 0;
gdjs.Game_45Code.GDStory1Objects2.length = 0;
gdjs.Game_45Code.GDStory1Objects3.length = 0;
gdjs.Game_45Code.GDStory1Objects4.length = 0;
gdjs.Game_45Code.GDStory1Objects5.length = 0;
gdjs.Game_45Code.GDEwokName2Objects1.length = 0;
gdjs.Game_45Code.GDEwokName2Objects2.length = 0;
gdjs.Game_45Code.GDEwokName2Objects3.length = 0;
gdjs.Game_45Code.GDEwokName2Objects4.length = 0;
gdjs.Game_45Code.GDEwokName2Objects5.length = 0;
gdjs.Game_45Code.GDEwokName3Objects1.length = 0;
gdjs.Game_45Code.GDEwokName3Objects2.length = 0;
gdjs.Game_45Code.GDEwokName3Objects3.length = 0;
gdjs.Game_45Code.GDEwokName3Objects4.length = 0;
gdjs.Game_45Code.GDEwokName3Objects5.length = 0;
gdjs.Game_45Code.GDEwokNameObjects1.length = 0;
gdjs.Game_45Code.GDEwokNameObjects2.length = 0;
gdjs.Game_45Code.GDEwokNameObjects3.length = 0;
gdjs.Game_45Code.GDEwokNameObjects4.length = 0;
gdjs.Game_45Code.GDEwokNameObjects5.length = 0;
gdjs.Game_45Code.GDPlayerNameObjects1.length = 0;
gdjs.Game_45Code.GDPlayerNameObjects2.length = 0;
gdjs.Game_45Code.GDPlayerNameObjects3.length = 0;
gdjs.Game_45Code.GDPlayerNameObjects4.length = 0;
gdjs.Game_45Code.GDPlayerNameObjects5.length = 0;
gdjs.Game_45Code.GDEwokText2Objects1.length = 0;
gdjs.Game_45Code.GDEwokText2Objects2.length = 0;
gdjs.Game_45Code.GDEwokText2Objects3.length = 0;
gdjs.Game_45Code.GDEwokText2Objects4.length = 0;
gdjs.Game_45Code.GDEwokText2Objects5.length = 0;
gdjs.Game_45Code.GDEwokText3Objects1.length = 0;
gdjs.Game_45Code.GDEwokText3Objects2.length = 0;
gdjs.Game_45Code.GDEwokText3Objects3.length = 0;
gdjs.Game_45Code.GDEwokText3Objects4.length = 0;
gdjs.Game_45Code.GDEwokText3Objects5.length = 0;
gdjs.Game_45Code.GDEwokTextObjects1.length = 0;
gdjs.Game_45Code.GDEwokTextObjects2.length = 0;
gdjs.Game_45Code.GDEwokTextObjects3.length = 0;
gdjs.Game_45Code.GDEwokTextObjects4.length = 0;
gdjs.Game_45Code.GDEwokTextObjects5.length = 0;
gdjs.Game_45Code.GDStoryE1hObjects1.length = 0;
gdjs.Game_45Code.GDStoryE1hObjects2.length = 0;
gdjs.Game_45Code.GDStoryE1hObjects3.length = 0;
gdjs.Game_45Code.GDStoryE1hObjects4.length = 0;
gdjs.Game_45Code.GDStoryE1hObjects5.length = 0;
gdjs.Game_45Code.GDDungeonBg32Objects1.length = 0;
gdjs.Game_45Code.GDDungeonBg32Objects2.length = 0;
gdjs.Game_45Code.GDDungeonBg32Objects3.length = 0;
gdjs.Game_45Code.GDDungeonBg32Objects4.length = 0;
gdjs.Game_45Code.GDDungeonBg32Objects5.length = 0;
gdjs.Game_45Code.GDDungeonBg3Objects1.length = 0;
gdjs.Game_45Code.GDDungeonBg3Objects2.length = 0;
gdjs.Game_45Code.GDDungeonBg3Objects3.length = 0;
gdjs.Game_45Code.GDDungeonBg3Objects4.length = 0;
gdjs.Game_45Code.GDDungeonBg3Objects5.length = 0;
gdjs.Game_45Code.GDDungeonBg22Objects1.length = 0;
gdjs.Game_45Code.GDDungeonBg22Objects2.length = 0;
gdjs.Game_45Code.GDDungeonBg22Objects3.length = 0;
gdjs.Game_45Code.GDDungeonBg22Objects4.length = 0;
gdjs.Game_45Code.GDDungeonBg22Objects5.length = 0;
gdjs.Game_45Code.GDDungeonBg2Objects1.length = 0;
gdjs.Game_45Code.GDDungeonBg2Objects2.length = 0;
gdjs.Game_45Code.GDDungeonBg2Objects3.length = 0;
gdjs.Game_45Code.GDDungeonBg2Objects4.length = 0;
gdjs.Game_45Code.GDDungeonBg2Objects5.length = 0;
gdjs.Game_45Code.GDDungeonBgObjects1.length = 0;
gdjs.Game_45Code.GDDungeonBgObjects2.length = 0;
gdjs.Game_45Code.GDDungeonBgObjects3.length = 0;
gdjs.Game_45Code.GDDungeonBgObjects4.length = 0;
gdjs.Game_45Code.GDDungeonBgObjects5.length = 0;
gdjs.Game_45Code.GDinvisibleWallObjects1.length = 0;
gdjs.Game_45Code.GDinvisibleWallObjects2.length = 0;
gdjs.Game_45Code.GDinvisibleWallObjects3.length = 0;
gdjs.Game_45Code.GDinvisibleWallObjects4.length = 0;
gdjs.Game_45Code.GDinvisibleWallObjects5.length = 0;
gdjs.Game_45Code.GDBosSoundObjects1.length = 0;
gdjs.Game_45Code.GDBosSoundObjects2.length = 0;
gdjs.Game_45Code.GDBosSoundObjects3.length = 0;
gdjs.Game_45Code.GDBosSoundObjects4.length = 0;
gdjs.Game_45Code.GDBosSoundObjects5.length = 0;
gdjs.Game_45Code.GDrightObjects1.length = 0;
gdjs.Game_45Code.GDrightObjects2.length = 0;
gdjs.Game_45Code.GDrightObjects3.length = 0;
gdjs.Game_45Code.GDrightObjects4.length = 0;
gdjs.Game_45Code.GDrightObjects5.length = 0;
gdjs.Game_45Code.GDleftObjects1.length = 0;
gdjs.Game_45Code.GDleftObjects2.length = 0;
gdjs.Game_45Code.GDleftObjects3.length = 0;
gdjs.Game_45Code.GDleftObjects4.length = 0;
gdjs.Game_45Code.GDleftObjects5.length = 0;
gdjs.Game_45Code.GDspaceObjects1.length = 0;
gdjs.Game_45Code.GDspaceObjects2.length = 0;
gdjs.Game_45Code.GDspaceObjects3.length = 0;
gdjs.Game_45Code.GDspaceObjects4.length = 0;
gdjs.Game_45Code.GDspaceObjects5.length = 0;
gdjs.Game_45Code.GDctrlObjects1.length = 0;
gdjs.Game_45Code.GDctrlObjects2.length = 0;
gdjs.Game_45Code.GDctrlObjects3.length = 0;
gdjs.Game_45Code.GDctrlObjects4.length = 0;
gdjs.Game_45Code.GDctrlObjects5.length = 0;
gdjs.Game_45Code.GDspaceTxObjects1.length = 0;
gdjs.Game_45Code.GDspaceTxObjects2.length = 0;
gdjs.Game_45Code.GDspaceTxObjects3.length = 0;
gdjs.Game_45Code.GDspaceTxObjects4.length = 0;
gdjs.Game_45Code.GDspaceTxObjects5.length = 0;
gdjs.Game_45Code.GDctrlTxObjects1.length = 0;
gdjs.Game_45Code.GDctrlTxObjects2.length = 0;
gdjs.Game_45Code.GDctrlTxObjects3.length = 0;
gdjs.Game_45Code.GDctrlTxObjects4.length = 0;
gdjs.Game_45Code.GDctrlTxObjects5.length = 0;
gdjs.Game_45Code.GDarrowTx2Objects1.length = 0;
gdjs.Game_45Code.GDarrowTx2Objects2.length = 0;
gdjs.Game_45Code.GDarrowTx2Objects3.length = 0;
gdjs.Game_45Code.GDarrowTx2Objects4.length = 0;
gdjs.Game_45Code.GDarrowTx2Objects5.length = 0;
gdjs.Game_45Code.GDarrowTxObjects1.length = 0;
gdjs.Game_45Code.GDarrowTxObjects2.length = 0;
gdjs.Game_45Code.GDarrowTxObjects3.length = 0;
gdjs.Game_45Code.GDarrowTxObjects4.length = 0;
gdjs.Game_45Code.GDarrowTxObjects5.length = 0;

gdjs.Game_45Code.eventsList28(runtimeScene);

return;

}

gdjs['Game_45Code'] = gdjs.Game_45Code;
